<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="124"/>
        <source>Administrator Access Required</source>
        <translation>Beheerdersrechten Vereist</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="125"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Voor deze bewerking zijn beheerdersrechten vereist. Start de toepassing opnieuw op en voer uw wachtwoord in wanneer daarom wordt gevraagd.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Pakket</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versie</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Grootte</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="192"/>
        <source>MX Package Installer</source>
        <translation>MX Pakket Installeerder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Populaire Toepassingen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Beheer populaire pakketten&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="673"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1178"/>
        <source>search</source>
        <translation>zoeken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="698"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <location filename="../src/mainwindow.ui" line="1373"/>
        <source>= Installed packages</source>
        <translation>= Geïnstalleerde pakketten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Ingeschakelde Pakketbronnen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Verwijder alle pakketten die zijn gemarkeerd als &amp;quot;autoverwijderbaar&amp;quot;. Als je ze wilt beheren, selecteer dan Autoverwijderbaar in de vervolgkeuzelijst.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Autoverwijder pakketten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1254"/>
        <source>Upgrade All</source>
        <translation>Waardeer Alles Op</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Installed:</source>
        <translation>Geïnstalleerd:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Total packages:</source>
        <translation>Totaal pakketten:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="649"/>
        <location filename="../src/mainwindow.ui" line="962"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Installeer ook &quot;Aanbevolen&quot; pakketten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Upgradable:</source>
        <translation>Opwaardeerbaar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Hide library and developer packages</source>
        <translation>Verberg bibliotheek- en ontwikkelaarspakketten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/mainwindow.ui" line="981"/>
        <location filename="../src/mainwindow.ui" line="1466"/>
        <source>Refresh list</source>
        <translation>Ververs lijst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="760"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <location filename="../src/mainwindow.ui" line="1421"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter pakketten op hun status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="763"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <location filename="../src/mainwindow.ui" line="1094"/>
        <location filename="../src/mainwindow.cpp" line="3947"/>
        <source>All packages</source>
        <translation>Alle pakketten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="772"/>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.cpp" line="3973"/>
        <source>Installed</source>
        <translation>Geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="777"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.cpp" line="3974"/>
        <source>Upgradable</source>
        <translation>Opwaardeerbaar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="782"/>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <location filename="../src/mainwindow.cpp" line="3941"/>
        <location filename="../src/mainwindow.cpp" line="3975"/>
        <location filename="../src/mainwindow.cpp" line="4180"/>
        <location filename="../src/mainwindow.cpp" line="4181"/>
        <source>Not installed</source>
        <translation>Niet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="1114"/>
        <location filename="../src/mainwindow.cpp" line="3330"/>
        <location filename="../src/mainwindow.cpp" line="3912"/>
        <location filename="../src/mainwindow.cpp" line="3976"/>
        <location filename="../src/mainwindow.cpp" line="4055"/>
        <location filename="../src/mainwindow.cpp" line="4146"/>
        <source>Autoremovable</source>
        <translation>Autoverwijderbaar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="729"/>
        <location filename="../src/mainwindow.ui" line="830"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Opwaardeerbaar pakket. Nieuwere versie beschikbaar in de geselecteerde pakketbron.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Test Pakketbron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="809"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="175"/>
        <location filename="../src/mainwindow.cpp" line="176"/>
        <source>For all users</source>
        <translation>Voor alle gebruikers</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1398"/>
        <source>For current user</source>
        <translation>Voor huidige gebruiker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1483"/>
        <source>Remote (repo):</source>
        <translation>Afstand (pakketbron):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.ui" line="1428"/>
        <location filename="../src/mainwindow.cpp" line="3923"/>
        <source>All apps</source>
        <translation>Alle apps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1433"/>
        <location filename="../src/mainwindow.cpp" line="3929"/>
        <source>All runtimes</source>
        <translation>Alle runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.cpp" line="3935"/>
        <source>All available</source>
        <translation>Alle beschikbare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1443"/>
        <location filename="../src/mainwindow.cpp" line="3920"/>
        <source>Installed apps</source>
        <translation>Geïnstalleerde apps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1448"/>
        <location filename="../src/mainwindow.cpp" line="3917"/>
        <source>Installed runtimes</source>
        <translation>Geïnstalleerde runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1453"/>
        <location filename="../src/mainwindow.cpp" line="3939"/>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <location filename="../src/mainwindow.cpp" line="4175"/>
        <source>All installed</source>
        <translation>Alles geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1233"/>
        <source>Total items </source>
        <translation>Totale items</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Installed apps:</source>
        <translation>Geïnstalleerde apps:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1299"/>
        <source>Advanced</source>
        <translation>Geavanceerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1328"/>
        <source>Total installed size:</source>
        <translation>totaal geïnstalleerd afmeting:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Remove unused runtimes</source>
        <translation>Ongebruikte looptijden verwijderen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="623"/>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1500"/>
        <location filename="../src/mainwindow.cpp" line="3504"/>
        <location filename="../src/mainwindow.cpp" line="3810"/>
        <source>Console Output</source>
        <translation>Console Weergave</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1506"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1516"/>
        <source>Respond here, or just press Enter</source>
        <translation>Antwoord hier, of klik op Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1849"/>
        <location filename="../src/mainwindow.cpp" line="3960"/>
        <location filename="../src/mainwindow.cpp" line="3971"/>
        <location filename="../src/mainwindow.cpp" line="4085"/>
        <location filename="../src/mainwindow.cpp" line="4125"/>
        <location filename="../src/mainwindow.cpp" line="4145"/>
        <location filename="../src/mainwindow.cpp" line="4172"/>
        <source>Install</source>
        <translation>Installeer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1581"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1600"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1603"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1641"/>
        <source>About this application</source>
        <translation>Over deze toepassing</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1644"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1650"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1688"/>
        <source>Display help </source>
        <translation>Toon help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1697"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1713"/>
        <source>Uninstall</source>
        <translation>Deïnstalleer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="380"/>
        <source>Uninstalling packages...</source>
        <translation>Pakketten deïnstalleren...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="385"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Pre-verwijderingsbewerkingen uitvoeren...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="405"/>
        <source>Running post-uninstall operations...</source>
        <translation>Na-deïnstallatie operaties uitvoeren...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="422"/>
        <source>Refreshing sources...</source>
        <translation>Bronnen verversen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="435"/>
        <location filename="../src/mainwindow.cpp" line="1897"/>
        <location filename="../src/mainwindow.cpp" line="2032"/>
        <location filename="../src/mainwindow.cpp" line="2208"/>
        <location filename="../src/mainwindow.cpp" line="2285"/>
        <location filename="../src/mainwindow.cpp" line="2639"/>
        <location filename="../src/mainwindow.cpp" line="2883"/>
        <location filename="../src/mainwindow.cpp" line="3323"/>
        <location filename="../src/mainwindow.cpp" line="3340"/>
        <location filename="../src/mainwindow.cpp" line="3482"/>
        <location filename="../src/mainwindow.cpp" line="3496"/>
        <location filename="../src/mainwindow.cpp" line="3646"/>
        <location filename="../src/mainwindow.cpp" line="3697"/>
        <location filename="../src/mainwindow.cpp" line="4269"/>
        <location filename="../src/mainwindow.cpp" line="4357"/>
        <location filename="../src/mainwindow.cpp" line="4389"/>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <location filename="../src/mainwindow.cpp" line="4503"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="436"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Er was een probleem met het updaten van de bronnen. Sommige bronnen kunnen geen updates aangeleverd hebben. Voor meer info bekijk: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <location filename="../src/mainwindow.cpp" line="580"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="586"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1111"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1117"/>
        <source>Please wait...</source>
        <translation>Even wachten aub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1656"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Je staat op het punt de MX Test pakketbron te gebruiken, welke pakketten enkel voor testdoeleinden aangeleverd worden. Het is mogelijk dat je je systeem breekt, dus het is aan te raden dat je een backup maakt van je systeem en installatie of een pakket tegelijk update. Geef alstublieft feedback in het FOrum zodat het pakket geëvalueerd kan worden voor het naar Main verhuist.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1665"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>U gaat de Debian Backports gebruiken welke pakketten bevat vanuit de eerstvolgende Debian uitgave (genaamd &apos;testing&apos;), aangepast en opnieuw gecompileerd voor gebruik op Debian stable. Ze kunnen niet zo uitgebreid getest worden als in de stabiele uitgaven van Debian en MX Linux en worden geleverd op een zoals-is basis, met het risico op incompatibiliteit met andere componenten in Debian stable. Voorzichtigheid is geboden!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1673"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux bevat de flatpak pakketbron enkel voor het gemak van de gebruiker, en is niet verantwoordelijk voor het functioneren van de daadwerkelijke individuele flatpaks. Voor meer, raadpleeg flatpaks in de Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1681"/>
        <location filename="../src/mainwindow.cpp" line="4493"/>
        <source>Warning</source>
        <translation>Waarschuwing</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1685"/>
        <source>Do not show this message again</source>
        <translation>Laat dit bericht niet meer zien</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1846"/>
        <source>Remove</source>
        <translation>Verwijder</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1862"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>De volgende pakketten zijn geselecteerd. Klik op Details weergeven voor een lijst met wijzigingen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1898"/>
        <location filename="../src/mainwindow.cpp" line="2033"/>
        <location filename="../src/mainwindow.cpp" line="2286"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet is niet beschikbaar, kan geen pakketlijst downloaden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1901"/>
        <source>Installing packages...</source>
        <translation>Pakketten installeren...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1959"/>
        <source>Post-processing...</source>
        <translation>Installatie nabewerking...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1991"/>
        <source>Pre-processing for </source>
        <translation>Installatie voorbereiding voor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2005"/>
        <source>Installing </source>
        <translation>Installeren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2012"/>
        <source>Post-processing for </source>
        <translation>Installatie nabewerking voor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2209"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2294"/>
        <source>Downloading package info...</source>
        <translation>Downloaden pakketten info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2640"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Het commando dpkg-query heeft een fout opgeleverd. Voer &apos;dpkg-query -W&apos; uit in terminal en controleer de uitvoer.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2884"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3019"/>
        <location filename="../src/mainwindow.cpp" line="3138"/>
        <location filename="../src/mainwindow.cpp" line="3167"/>
        <source>Package info</source>
        <translation>Pakket info</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3047"/>
        <location filename="../src/mainwindow.cpp" line="4424"/>
        <source>More &amp;info...</source>
        <translation>Meer &amp;informatie...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3081"/>
        <source>Packages to be installed: </source>
        <translation>Pakketten worden geïnstalleerd:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <location filename="../src/mainwindow.cpp" line="3319"/>
        <location filename="../src/mainwindow.cpp" line="3337"/>
        <location filename="../src/mainwindow.cpp" line="3457"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="4266"/>
        <location filename="../src/mainwindow.cpp" line="4353"/>
        <location filename="../src/mainwindow.cpp" line="4383"/>
        <location filename="../src/mainwindow.cpp" line="4461"/>
        <source>Done</source>
        <translation>Klaar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3307"/>
        <location filename="../src/mainwindow.cpp" line="3319"/>
        <location filename="../src/mainwindow.cpp" line="3337"/>
        <location filename="../src/mainwindow.cpp" line="3457"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="4266"/>
        <location filename="../src/mainwindow.cpp" line="4353"/>
        <location filename="../src/mainwindow.cpp" line="4383"/>
        <location filename="../src/mainwindow.cpp" line="4461"/>
        <location filename="../src/mainwindow.cpp" line="4500"/>
        <source>Processing finished successfully.</source>
        <translation>Proces succesvol beëindigd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3324"/>
        <location filename="../src/mainwindow.cpp" line="3341"/>
        <location filename="../src/mainwindow.cpp" line="4270"/>
        <location filename="../src/mainwindow.cpp" line="4358"/>
        <location filename="../src/mainwindow.cpp" line="4390"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Probleem gevonden tijdens installatie, inspecteer aub de console weergave.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3351"/>
        <source>About %1</source>
        <translation>Over %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3352"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3354"/>
        <source>Package Installer for MX Linux</source>
        <translation>Pakket Installeerder voor MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3356"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3357"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3369"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3482"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>We kwamen een probleem tegen tijdens het deïnstalleren , controleer aub de output</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="4500"/>
        <source>Success</source>
        <translation>Gelukt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3496"/>
        <location filename="../src/mainwindow.cpp" line="4503"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>We kwamen een probleem tegen tijdens het deïnstalleren van het programma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="3698"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Kon de lijst met pakketten niet downloaden. Controleer uw APT bronnen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3746"/>
        <location filename="../src/mainwindow.cpp" line="3792"/>
        <source>Flatpak not installed</source>
        <translation>Flatpaklniet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3747"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak is momenteel niet geïnstalleerd.
OK om door te gaan en te installeren?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3792"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak is niet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3814"/>
        <source>Needs re-login</source>
        <translation>Heeft opnieuw inloggen nodig</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3815"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Het kan zijn dat u moet uit- en inloggen om de geïnstalleerde onderdelen in het menu te zien</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3960"/>
        <location filename="../src/mainwindow.cpp" line="3971"/>
        <location filename="../src/mainwindow.cpp" line="4083"/>
        <location filename="../src/mainwindow.cpp" line="4147"/>
        <source>Mark keep</source>
        <translation>Markeer behouden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3988"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3989"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4085"/>
        <location filename="../src/mainwindow.cpp" line="4145"/>
        <source>Upgrade</source>
        <translation>Opwaarderen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Quit?</source>
        <translation>Stoppen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Proces loopt nog, stoppen kan het systeem instabiel achter laten.&lt;p&gt;&lt;b&gt;Weet u zeker dat u MX Pakketinstalleerder wilt afsluiten?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4125"/>
        <source>Reinstall</source>
        <translation>Opnieuw installeren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Probleem gedetecteerd tijdens de laatste bewerking, inspecteer de console-uitgang.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4494"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Potentieel gevaarlijke operatie.
Zorg ervoor dat u de lijst met te verwijderen pakketten zorgvuldig controleert.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Beheer Flatpak Op Afstand</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Voor alle gebruikers</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Voor huidige gebruiker</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>Voer Flatpak op afstand URL in</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>Voer Flatpakref locatie in om app te installeren</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Flatpak op afstanden (pakketbronnen) toevoegen of verwijderen, of installeer apps met flatpakref URL of pad</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Verwijder op afstand</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Voeg op afstand toe</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Installeer app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Niet verwijderbaar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub is de hoofd Flatpak op afstand en zal niet verwijderd worden</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Fout bij toevoegen op afstand</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Kan de op afstand niet opzetten - commando gaf een fout. Controleer alstublieft het op afstand adres en probeer opnieuw</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Gelukt</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Op afstand succesvol toegevoegd</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Pakket</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Repoversie</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Beschrijving</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categorie</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pakket</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Informatie</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Beschrijving</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="72"/>
        <location filename="../src/about.cpp" line="82"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="73"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Waarschuwing</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Dpkg/apt database is vergrendeld door een ander programma: %1
Sluit het programma of wacht tot het klaar is met verwerken en probeer het opnieuw.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="90"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Package Installer is een hulpprogramma voor het beheer van pakketten op MX Linux
- installeert populaire programma&apos;s van verschillende bronnen
- installeert programma&apos;s van de MX Test repo
- installeert programma&apos;s van de Debian Backports repo
- installeert flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="98"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Sla de online controle over als deze ten onrechte meldt dat er geen internettoegang is.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <location filename="../src/main.cpp" line="116"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="109"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>U lijkt ingelogd te zijn als root, gelieve uit te loggen en in te loggen als normale gebruiker om dit programma te gebruiken.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="117"/>
        <source>You must run this program with admin access.</source>
        <translation>Je moet dit programma uitvoeren met admin-toegang.</translation>
    </message>
</context>
</TS>