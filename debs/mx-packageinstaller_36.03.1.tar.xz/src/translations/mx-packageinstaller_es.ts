<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Reinicia la aplicación e ingresa tu contraseña cuando se te solicite.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Nombre completo</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Rama</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>MX Package Installer</source>
        <translation>MX Instalador de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Aplicaciones populares</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Gestionar paquetes populares&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="673"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1178"/>
        <source>search</source>
        <translation>buscar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="698"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <location filename="../src/mainwindow.ui" line="1373"/>
        <source>= Installed packages</source>
        <translation>= Paquetes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Repositorios habilitados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Elimina todos los paquetes marcados como &amp;quot;autoremovible&amp;quot;. Si desea gestionarlos, seleccione Autoremovible en el cuadro de selección desplegable.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Paquetes autoremovibles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1254"/>
        <source>Upgrade All</source>
        <translation>Actualizar Todos:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Installed:</source>
        <translation>Instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Total packages:</source>
        <translation>Paquetes totales:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="649"/>
        <location filename="../src/mainwindow.ui" line="962"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Instalar también los paquetes &quot;Recomendados&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Upgradable:</source>
        <translation>Actualizable:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Hide library and developer packages</source>
        <translation>Ocultar paquetes de bibliotecas y desarrolladores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/mainwindow.ui" line="981"/>
        <location filename="../src/mainwindow.ui" line="1466"/>
        <source>Refresh list</source>
        <translation>Recargar lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="760"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <location filename="../src/mainwindow.ui" line="1421"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar paquetes según su estado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="763"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <location filename="../src/mainwindow.ui" line="1094"/>
        <location filename="../src/mainwindow.cpp" line="4100"/>
        <source>All packages</source>
        <translation>Todos los paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="772"/>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.cpp" line="4126"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="777"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.cpp" line="4127"/>
        <source>Upgradable</source>
        <translation>Actualizable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="782"/>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <location filename="../src/mainwindow.cpp" line="4093"/>
        <location filename="../src/mainwindow.cpp" line="4128"/>
        <source>Not installed</source>
        <translation>No instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="1114"/>
        <location filename="../src/mainwindow.cpp" line="3467"/>
        <location filename="../src/mainwindow.cpp" line="4064"/>
        <location filename="../src/mainwindow.cpp" line="4129"/>
        <location filename="../src/mainwindow.cpp" line="4208"/>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>Autoremovable</source>
        <translation>Autoremovible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="729"/>
        <location filename="../src/mainwindow.ui" line="830"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Paquete actualizable. Versión más reciente disponible en el repositorio seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Repo de prueba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="809"/>
        <source>Debian Backports</source>
        <translation>Backports de Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <location filename="../src/mainwindow.cpp" line="273"/>
        <source>For all users</source>
        <translation>Para todos los usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1398"/>
        <source>For current user</source>
        <translation>Para el usuario actual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1483"/>
        <source>Remote (repo):</source>
        <translation>Remoto (repo):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.ui" line="1428"/>
        <location filename="../src/mainwindow.cpp" line="4075"/>
        <source>All apps</source>
        <translation>Todas las apps</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1433"/>
        <location filename="../src/mainwindow.cpp" line="4081"/>
        <source>All runtimes</source>
        <translation>Todos los binarios de ejecución</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>All available</source>
        <translation>Todos disponibles</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1443"/>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Installed apps</source>
        <translation>Apps instaladas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1448"/>
        <location filename="../src/mainwindow.cpp" line="4069"/>
        <source>Installed runtimes</source>
        <translation>Binarios de ejecución instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1453"/>
        <location filename="../src/mainwindow.cpp" line="4091"/>
        <source>All installed</source>
        <translation>Todos los instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1233"/>
        <source>Total items </source>
        <translation>Total de elementos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Installed apps:</source>
        <translation>Apps instaladas:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1299"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1328"/>
        <source>Total installed size:</source>
        <translation>Tamaño total instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Remove unused runtimes</source>
        <translation>Eliminar los tiempos de ejecución no usados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="623"/>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Select all</source>
        <translation>Seleccionar todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1500"/>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <location filename="../src/mainwindow.cpp" line="3945"/>
        <source>Console Output</source>
        <translation>Salida en consola</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1506"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1516"/>
        <source>Respond here, or just press Enter</source>
        <translation>Responda aquí, o sólo presione Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1979"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4325"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1581"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1600"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1603"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1641"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1644"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1650"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1688"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1697"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1713"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Uninstalling packages...</source>
        <translation>Desinstalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="482"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Ejecutando las operaciones de predesinstalación...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Running post-uninstall operations...</source>
        <translation>Ejecutando operaciones de post-desinstalación....</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="519"/>
        <source>Refreshing sources...</source>
        <translation>Recargando fuentes.. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <location filename="../src/mainwindow.cpp" line="2027"/>
        <location filename="../src/mainwindow.cpp" line="2169"/>
        <location filename="../src/mainwindow.cpp" line="2338"/>
        <location filename="../src/mainwindow.cpp" line="2415"/>
        <location filename="../src/mainwindow.cpp" line="2774"/>
        <location filename="../src/mainwindow.cpp" line="3018"/>
        <location filename="../src/mainwindow.cpp" line="3460"/>
        <location filename="../src/mainwindow.cpp" line="3477"/>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="3780"/>
        <location filename="../src/mainwindow.cpp" line="3831"/>
        <location filename="../src/mainwindow.cpp" line="4416"/>
        <location filename="../src/mainwindow.cpp" line="4505"/>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <location filename="../src/mainwindow.cpp" line="4635"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Hubo problemas al recargar las fuentes. Algunas fuentes parecen no tener actualizaciones. Para más información, revise:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>No se pudo determinar la versión de Debian. Seleccione la suya:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Debian Version</source>
        <translation>Versión de Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1232"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1238"/>
        <source>Please wait...</source>
        <translation>Por favor, espere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Está a punto de utilizar el repositorio MX de prueba, cuyos paquetes se proporcionan solo con fines de prueba. Podrían llegar a dañar su sistema, por lo que se sugiere que haga un respaldo de su sistema e instale y/o actualice solo un paquete a la vez. Por favor, envíe sus comentarios al Foro para que los paquetes puedan ser evaluados antes de pasar al repositorio principal (Main) </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1797"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Va a usar Debian Backports, que contiene paquetes tomados de la próxima versión de Debian (llamada &apos;prueba&apos;), ajustados y recompilados para el uso en Debian Estable. Los mismos no pueden ser probados extensivamente como en las versiones estables de Debian y MX Linux, y se proporcionan &apos;como están&apos;, con el riesgo de incompatibilidades con otros componentes en Debian Estable. ¡Utilícelos con cuidado!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1805"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux incluye este repositorio de flatpaks solo para la conveniencia de los usuarios, y no es responsable de la funcionalidad de los flatpaks individuales. Para más información, consulte flatpaks en la Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1813"/>
        <location filename="../src/mainwindow.cpp" line="4663"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1817"/>
        <source>Do not show this message again</source>
        <translation>No mostrar este mensaje de nuevo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1976"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1992"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Se han seleccionado los siguientes paquetes. Haga clic en Mostrar detalles para ver la lista de cambios.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2028"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <location filename="../src/mainwindow.cpp" line="2416"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet no esta disponible, no puede descargar la lista de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2031"/>
        <source>Installing packages...</source>
        <translation>Instalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Post-processing...</source>
        <translation>Post-procesamiento...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2126"/>
        <source>Pre-processing for </source>
        <translation>Pre-procesamiento para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2141"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2148"/>
        <source>Post-processing for </source>
        <translation>Post-procesamiento para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2339"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Hubo un error al escribir el archivo: %1. Por favor, compruebe si tiene suficiente espacio libre en su disco</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2424"/>
        <source>Downloading package info...</source>
        <translation>Bajando info de paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2775"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>El comando dpkg-query devolvió un error. Ejecute &apos;dpkg-query -W&apos; en la terminal y verifique el resultado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3019"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>El comando dpkg-query devolvió un error. Ejecute &apos;dpkg-query -W&apos; en la terminal y verifique el resultado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3154"/>
        <location filename="../src/mainwindow.cpp" line="3273"/>
        <location filename="../src/mainwindow.cpp" line="3302"/>
        <source>Package info</source>
        <translation>Info de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3182"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <source>More &amp;info...</source>
        <translation>Más &amp;información...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3216"/>
        <source>Packages to be installed: </source>
        <translation>Paquetes a instalar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <source>Done</source>
        <translation>Listo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Processing finished successfully.</source>
        <translation>Procesamiento completado con éxito. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3452"/>
        <location filename="../src/mainwindow.cpp" line="4527"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3461"/>
        <location filename="../src/mainwindow.cpp" line="3478"/>
        <location filename="../src/mainwindow.cpp" line="4417"/>
        <location filename="../src/mainwindow.cpp" line="4506"/>
        <location filename="../src/mainwindow.cpp" line="4539"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Problemas detectadso durante la instalación; favor inspeccionar la salida en consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3488"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3489"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3491"/>
        <source>Package Installer for MX Linux</source>
        <translation>Instalador de paquetes para MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Derechos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3494"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3500"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3596"/>
        <location filename="../src/mainwindow.cpp" line="4624"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3602"/>
        <location filename="../src/mainwindow.cpp" line="4626"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3603"/>
        <location filename="../src/mainwindow.cpp" line="4627"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Hubo un problema desinstalando; favor revisae la salida.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Hubo un problema durante la desinstalación del programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3781"/>
        <location filename="../src/mainwindow.cpp" line="3832"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>No se ha podido descargar la lista de paquetes. Por favor, compruebe sus fuentes APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3880"/>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak no esta instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3881"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak no está instalado.
¿Está bien continuarr e instalarlo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak no fue instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3949"/>
        <source>Needs re-login</source>
        <translation>Necesita re-login</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3950"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Quizás necesite cerrar/iniciar sesión para ver en el menú los elementos instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4236"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Mark keep</source>
        <translation>Marcar para conservar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <source>Select/deselect all upgradable</source>
        <translation>Seleccionar/deseleccionar todo lo actualizable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4142"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Seleccionar/deseccionar todo lo autoremovible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4445"/>
        <location filename="../src/mainwindow.cpp" line="4585"/>
        <source>Quit?</source>
        <translation>¿Salir?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4586"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>El proceso todavía se está ejecutando, salir puede causar inestabilidad en el sistema.&lt;p&gt;&lt;b&gt;¿Está seguro de que desea salir de MX Instalador de paquetes?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <source>Reinstall</source>
        <translation>Reinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4636"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Problema detectado durante la última operación, por favor inspeccione la salida de la consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4664"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Operación potencialmente peligrosa.
Por favor, asegúrese de comprobar cuidadosamente la lista de paquetes que deben ser eliminados.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Gestionar Remotos de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Para todos los usuarios</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Para el usuario actual</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>ingresar el URL remoto de Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>ingresar la ubicación de Flatpakref para instalar el app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Agregar o quitar los repos (remotos) de flatpak, o instalar apps utilizando el URL o ruta del flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Remover el remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Agregar el remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalar la app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>No es removible</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub es el principal repo remoto de Flatpak y no será removido</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Error al agregar remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>No se pudo agregar remoto - el comando produjo un error. Favor verificar la dirección remota e intentar de nuevo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Exito</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Remoto agregado con exito</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Versión del Repositorio</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>La base de datos dpkg/apt está bloqueada por otro programa: %1
Cierre el programa o espere a que termine el proceso e inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Instalador de Paquetes es una herramienta utilizada para la gestión de paquetes en MX Linux
    - instala programas populares de diferentes fuentes
    - instala programas del repositorio MX Test
    - instala programas del repositorio Debian Backports
    - instala flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Omitir la comprobación en línea si informa falsamente de la falta de acceso a Internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Debe ejecutar este programa con acceso de administrador.</translation>
    </message>
</context>
</TS>