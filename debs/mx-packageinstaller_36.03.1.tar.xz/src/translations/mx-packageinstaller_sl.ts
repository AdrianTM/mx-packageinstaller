<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Zahtevan je skrbniški dostop</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Za ta operacijo je potreben skrbniški dostop. Ponovno zaženite program in vnesite geslo, ko ga bo program zahteval.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Polno ime</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Različica</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Veja</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>MX Package Installer</source>
        <translation>MX namestilnik paketov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Priljubljeni programi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Upravljanje priljubljenih paketov&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="673"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1178"/>
        <source>search</source>
        <translation>iskanje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="698"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <location filename="../src/mainwindow.ui" line="1373"/>
        <source>= Installed packages</source>
        <translation>= Nameščeni paketi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Vklopljena skladišča</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Odstrani vse paketov, ki imajo oznako &amp;quot;autoremovable&amp;quot;. Za urejanje uporabite možnost Samodejno odstranljivo iz spustnega izbirnika.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Samodejna odstranitev paketov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1254"/>
        <source>Upgrade All</source>
        <translation>Nadgradi vse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Installed:</source>
        <translation>Nameščenih:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Total packages:</source>
        <translation>Skupaj paketov:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="649"/>
        <location filename="../src/mainwindow.ui" line="962"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Namesti tudi &quot;priporočene&quot; pakete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Upgradable:</source>
        <translation>Nadgradljivih:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Hide library and developer packages</source>
        <translation>Skrij knjižnice in razvojne pakete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/mainwindow.ui" line="981"/>
        <location filename="../src/mainwindow.ui" line="1466"/>
        <source>Refresh list</source>
        <translation>Osveži seznam</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="760"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <location filename="../src/mainwindow.ui" line="1421"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtriranje paketov glede na njihovo status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="763"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <location filename="../src/mainwindow.ui" line="1094"/>
        <location filename="../src/mainwindow.cpp" line="4100"/>
        <source>All packages</source>
        <translation>Vsi paketi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="772"/>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.cpp" line="4126"/>
        <source>Installed</source>
        <translation>Nameščeno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="777"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.cpp" line="4127"/>
        <source>Upgradable</source>
        <translation>Nadgradljivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="782"/>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <location filename="../src/mainwindow.cpp" line="4093"/>
        <location filename="../src/mainwindow.cpp" line="4128"/>
        <source>Not installed</source>
        <translation>Ni nameščeno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="1114"/>
        <location filename="../src/mainwindow.cpp" line="3467"/>
        <location filename="../src/mainwindow.cpp" line="4064"/>
        <location filename="../src/mainwindow.cpp" line="4129"/>
        <location filename="../src/mainwindow.cpp" line="4208"/>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>Autoremovable</source>
        <translation>Samodejno odstranljivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="729"/>
        <location filename="../src/mainwindow.ui" line="830"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= nadgradljiv paket. V izbranem skladišču je na voljo novejša različica.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX testno skladišče</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="809"/>
        <source>Debian Backports</source>
        <translation>Debian backporti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <location filename="../src/mainwindow.cpp" line="273"/>
        <source>For all users</source>
        <translation>Za vse uporabnike</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1398"/>
        <source>For current user</source>
        <translation>Za trenutnega uporabnika</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1483"/>
        <source>Remote (repo):</source>
        <translation>Oddaljeno (skladišče):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.ui" line="1428"/>
        <location filename="../src/mainwindow.cpp" line="4075"/>
        <source>All apps</source>
        <translation>Vsi programi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1433"/>
        <location filename="../src/mainwindow.cpp" line="4081"/>
        <source>All runtimes</source>
        <translation>Vse izvršljivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>All available</source>
        <translation>Vse, kar je na voljo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1443"/>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Installed apps</source>
        <translation>Nameščeni programi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1448"/>
        <location filename="../src/mainwindow.cpp" line="4069"/>
        <source>Installed runtimes</source>
        <translation>Nameščeno izvršljivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1453"/>
        <location filename="../src/mainwindow.cpp" line="4091"/>
        <source>All installed</source>
        <translation>Vse nameščeno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1233"/>
        <source>Total items </source>
        <translation>Skupaj enot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Installed apps:</source>
        <translation>Nameščeni programi:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1299"/>
        <source>Advanced</source>
        <translation>Napredno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1328"/>
        <source>Total installed size:</source>
        <translation>Skupna velikost namestitve:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Remove unused runtimes</source>
        <translation>Odstrani neuporabljene zagone</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="623"/>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Select all</source>
        <translation>Izberi vse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1500"/>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <location filename="../src/mainwindow.cpp" line="3945"/>
        <source>Console Output</source>
        <translation>Izpis terminala</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1506"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1516"/>
        <source>Respond here, or just press Enter</source>
        <translation>Odzovite se tukaj ali zgolj pritisnite Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1979"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4325"/>
        <source>Install</source>
        <translation>Namesti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1581"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1600"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1603"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1641"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1644"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1650"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1688"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1697"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1713"/>
        <source>Uninstall</source>
        <translation>Odstrani</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Uninstalling packages...</source>
        <translation>Odstranjevanje paketov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="482"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Izvedba opravil pred odstranitvijo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Running post-uninstall operations...</source>
        <translation>Izvajam opravila po namestitvi...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="519"/>
        <source>Refreshing sources...</source>
        <translation>Osvežujem vire...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <location filename="../src/mainwindow.cpp" line="2027"/>
        <location filename="../src/mainwindow.cpp" line="2169"/>
        <location filename="../src/mainwindow.cpp" line="2338"/>
        <location filename="../src/mainwindow.cpp" line="2415"/>
        <location filename="../src/mainwindow.cpp" line="2774"/>
        <location filename="../src/mainwindow.cpp" line="3018"/>
        <location filename="../src/mainwindow.cpp" line="3460"/>
        <location filename="../src/mainwindow.cpp" line="3477"/>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="3780"/>
        <location filename="../src/mainwindow.cpp" line="3831"/>
        <location filename="../src/mainwindow.cpp" line="4416"/>
        <location filename="../src/mainwindow.cpp" line="4505"/>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <location filename="../src/mainwindow.cpp" line="4635"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Prišlo je do težav pri osveževanju virov. Nekateri viri morda niso pravilno podali posodobitev. Za več informacij preveri:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Ni bilo mogoče določiti različice Debiana. Izberite svojo različico:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Debian Version</source>
        <translation>Debian različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1232"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1238"/>
        <source>Please wait...</source>
        <translation>Prosimo, počakajte...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Ste na tem, da bi uporabljali testna skladišča, katerih paketi so namenjeni zgolj preizkušanju. Obstaja možnost, da bodo ti pokvarili vaš sistem, zato svetujemo, da naredite varnostno kopijo svojega sistema in da naenkrat namestite ali posodobite le po en paket. Prosimo, da posredujete povratne informacije na forumu, zato da bo lahko paket ovrednoten in prestavljen v glavno skladišče.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1797"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Ste na tem, da boste uporabili Debian backporte, ki vsebujejo pakete iz naslednjih izdaj Debiana (poimenovane &apos;testing&apos;) in ki so prilagojeni za rabo s stabilnim Debianom. Niso preizkušeni tako intenzivno, kot stabilne izdaje za Debian ali MX Linux in so lahko nezdružljivi z drugimi komponentami stabilnega Debiana. Uporabljajte previdno!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1805"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux vsebuje to skladišče flatpakov zgolj zato, da bi ustregel določenim uporabnikom in ni odgovoren za njihovo funkcionalnost. Za več informacij preverite flatpaks Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1813"/>
        <location filename="../src/mainwindow.cpp" line="4663"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1817"/>
        <source>Do not show this message again</source>
        <translation>Ne prikaži več tega sporočila.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1976"/>
        <source>Remove</source>
        <translation>Briši</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1992"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Izbrani so bili naslednji paketi. Kliknite na Prikaži podrobnosti za seznam sprememb.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2028"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <location filename="../src/mainwindow.cpp" line="2416"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Ni povezave s spletom, zato ni mogoče naložiti seznama paketov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2031"/>
        <source>Installing packages...</source>
        <translation>Nameščanje paketov...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Post-processing...</source>
        <translation>Zaključna obdelava...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2126"/>
        <source>Pre-processing for </source>
        <translation>Priprava obdelave...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2141"/>
        <source>Installing </source>
        <translation>Nameščanje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2148"/>
        <source>Post-processing for </source>
        <translation>Zaključna obdelava za</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2339"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Pri prenosu ali zapisovanju datoteke %1 je prišlo do napake. Preverite spletno povezavo in prostor na disku.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2424"/>
        <source>Downloading package info...</source>
        <translation>Prenašanje informacij o paketu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2775"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Ukaz za poizvedbo dpkg-query je vrnil napako. V terminalu zaženite &apos;dpkg-query -W&apos; in preverite izpis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3019"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Ukaz za poizvedbo dpkg-query je vrnil napako. V terminalu zaženite &apos;dpkg-query -W&apos; in preverite izpis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3154"/>
        <location filename="../src/mainwindow.cpp" line="3273"/>
        <location filename="../src/mainwindow.cpp" line="3302"/>
        <source>Package info</source>
        <translation>Informacije o paketu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3182"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <source>More &amp;info...</source>
        <translation>&amp;Več podatkov...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3216"/>
        <source>Packages to be installed: </source>
        <translation>Paketi, ki bodo nameščeni:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <source>Done</source>
        <translation>Zaključeno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Processing finished successfully.</source>
        <translation>Obdelava je bilo uspešno zaključeno.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3452"/>
        <location filename="../src/mainwindow.cpp" line="4527"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3461"/>
        <location filename="../src/mainwindow.cpp" line="3478"/>
        <location filename="../src/mainwindow.cpp" line="4417"/>
        <location filename="../src/mainwindow.cpp" line="4506"/>
        <location filename="../src/mainwindow.cpp" line="4539"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Ob nameščanju je bila odkrita napaka. Prosimo preverite izpis konzole.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3488"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3489"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3491"/>
        <source>Package Installer for MX Linux</source>
        <translation>Namestilnik paketov za MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3494"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3500"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3596"/>
        <location filename="../src/mainwindow.cpp" line="4624"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3602"/>
        <location filename="../src/mainwindow.cpp" line="4626"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3603"/>
        <location filename="../src/mainwindow.cpp" line="4627"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Pri odstranjevanju se je pojavila težava. Preverite izpis terminala</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Success</source>
        <translation>Operacija je uspela</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Pri odstranjevanju se je pojavila težava</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3781"/>
        <location filename="../src/mainwindow.cpp" line="3832"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Seznama paketov ni bilo mogoče prenesti. Preverite APT vire.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3880"/>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ni bil nameščen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3881"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatopak trenutno ni nameščen.
Ali naj ga namestim?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak ni bil namesčen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3949"/>
        <source>Needs re-login</source>
        <translation>Potreben je ponovni vpis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3950"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Za prikaz nameščenih paketov v meniju se bo morda potrebno ponovno vpisati.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4236"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Mark keep</source>
        <translation>Obdrži</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <source>Select/deselect all upgradable</source>
        <translation>Izberi/opusti ve nadgradljive</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4142"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Izberi/opusti vse samodejno odstranljive</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Upgrade</source>
        <translation>Nadgradi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4445"/>
        <location filename="../src/mainwindow.cpp" line="4585"/>
        <source>Quit?</source>
        <translation>Končam?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4586"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Proces se še izvaja, dokončanje bi lahko destabiliziralo sistem.&lt;p&gt;&lt;b&gt; Ali ste prepričani, da bi radi zaustili MX namestilnik paketov?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <source>Reinstall</source>
        <translation>Ponovno namesti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4636"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Med zadnjo operacijo je bila odkrita napaka. Preverite izpis konzole.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4664"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Potencialno nevarno dejanje.
Skrbno preglejte seznam paketov, ki bodo odstranjeni.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Upravljaj Flatpak oddaljenih strežnikov</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Za vse uporabnike</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Za trenutnega uporabnika</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>vnesite oddaljeni URL za Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>za namestitev aplikacije vnesite Flatpakref lokacijo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Dodaj ali odstrani flatpak oddaljni dostop (skladišča) ali namesti flatpakref URL ali pot</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Odstrani oddaljeni strežnik</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Dodaj oddaljeni strežnik</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Namesti aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Ni odstranljivo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub je glavni oddaljeni Flatpak strežnik in ne bo odstranjen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Napaka pri dodajanju oddaljenega dostopa</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Neupsešno dodajanje oddaljenega dostopa - ukaz je vrnil napako. Preverite naslov oddaljenega strežnika in poskusite znova</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Operacija je uspela</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Oddaljeni strežnik je bil uspešno dodan</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Različica skladišča:</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Nameščeno</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategorija</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Informacije</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Dpgk/apt podatkovno bazo je zaklenil drug program: %1
Zaprite ta program ali počakajte, da konča z obdelavo in poskusite znova.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Namestilnik paketov je orodje za upravljanje paketov v okolju MX Linux
    - namesti priljubljene programe iz različnih virov
    - namesti programe iz MX testnega skladišča
    - namesti programe iz Debian Backport skladišča
    - namesti flatpak pakete</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Preskoči spletno preverjanje, če napačno javlja odsotnost spletne povezave.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijavljeni ste kot korenski uporabnik. Izpišite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Ta program je potrebno zagnati s skrbniškim dostopom</translation>
    </message>
</context>
</TS>