<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>É necessário ter permissões de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operação requer  permissões de administrador. Reinicie o programa e digite a sua senha quando esta for solicitada.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Nome Completo</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Ramo</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>MX Package Installer</source>
        <translation>MX Instalador de Pacotes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Aplicações seleccionadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Instalar/Desinstalar pacotes colectados pela equipa do MX&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="673"/>
        <location filename="../src/mainwindow.ui" line="1057"/>
        <location filename="../src/mainwindow.ui" line="1178"/>
        <source>search</source>
        <translation>procurar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="698"/>
        <location filename="../src/mainwindow.ui" line="1137"/>
        <location filename="../src/mainwindow.ui" line="1373"/>
        <source>= Installed packages</source>
        <translation>= Pacotes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Dos repositórios activos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remover todos os pacotes que estão marcados como &amp;quot;autoremovable&amp;quot;. Se desejar geri-los, escolha Autoremovível na caixa de seleção.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Remover pacotes automaticamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1254"/>
        <source>Upgrade All</source>
        <translation>Atualizar todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Installed:</source>
        <translation>Instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="922"/>
        <source>Total packages:</source>
        <translation>Total de pacotes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="649"/>
        <location filename="../src/mainwindow.ui" line="962"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Instalar também pacotes &quot;Recomendados&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Upgradable:</source>
        <translation>Atualizáveis:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Hide library and developer packages</source>
        <translation>Ocultar pacotes de bibliotecas e de programador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="610"/>
        <location filename="../src/mainwindow.ui" line="981"/>
        <location filename="../src/mainwindow.ui" line="1466"/>
        <source>Refresh list</source>
        <translation>Recarregar a lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="760"/>
        <location filename="../src/mainwindow.ui" line="1087"/>
        <location filename="../src/mainwindow.ui" line="1421"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar pacotes pelo estado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="763"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1090"/>
        <location filename="../src/mainwindow.ui" line="1094"/>
        <location filename="../src/mainwindow.cpp" line="4100"/>
        <source>All packages</source>
        <translation>Todos os pacotes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="772"/>
        <location filename="../src/mainwindow.ui" line="1099"/>
        <location filename="../src/mainwindow.cpp" line="4126"/>
        <source>Installed</source>
        <translation>Instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="777"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.cpp" line="4127"/>
        <source>Upgradable</source>
        <translation>Atualizáveis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="782"/>
        <location filename="../src/mainwindow.ui" line="1109"/>
        <location filename="../src/mainwindow.ui" line="1458"/>
        <location filename="../src/mainwindow.cpp" line="4093"/>
        <location filename="../src/mainwindow.cpp" line="4128"/>
        <source>Not installed</source>
        <translation>Não instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="787"/>
        <location filename="../src/mainwindow.ui" line="1114"/>
        <location filename="../src/mainwindow.cpp" line="3467"/>
        <location filename="../src/mainwindow.cpp" line="4064"/>
        <location filename="../src/mainwindow.cpp" line="4129"/>
        <location filename="../src/mainwindow.cpp" line="4208"/>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>Autoremovable</source>
        <translation>Autoremovível</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="729"/>
        <location filename="../src/mainwindow.ui" line="830"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Pacote instalado. Versão mais recente disponível noutro repositório.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Test</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="809"/>
        <source>Debian Backports</source>
        <translation>Debian Retroportados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1160"/>
        <source>Flatpaks</source>
        <translation>Pacotes flatpak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <location filename="../src/mainwindow.ui" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <location filename="../src/mainwindow.cpp" line="273"/>
        <source>For all users</source>
        <translation>Para todos os utilizadores</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1398"/>
        <source>For current user</source>
        <translation>Para o presente utilizador</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1483"/>
        <source>Remote (repo):</source>
        <translation>Remoto (repositório):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1424"/>
        <location filename="../src/mainwindow.ui" line="1428"/>
        <location filename="../src/mainwindow.cpp" line="4075"/>
        <source>All apps</source>
        <translation>Aplicações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1433"/>
        <location filename="../src/mainwindow.cpp" line="4081"/>
        <source>All runtimes</source>
        <translation>Software &apos;runtime&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.cpp" line="4087"/>
        <source>All available</source>
        <translation>Todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1443"/>
        <location filename="../src/mainwindow.cpp" line="4072"/>
        <source>Installed apps</source>
        <translation>Aplicações instaladas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1448"/>
        <location filename="../src/mainwindow.cpp" line="4069"/>
        <source>Installed runtimes</source>
        <translation>Software &apos;runtime&apos; instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1453"/>
        <location filename="../src/mainwindow.cpp" line="4091"/>
        <source>All installed</source>
        <translation>Todos os instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1233"/>
        <source>Total items </source>
        <translation>Total de itens </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Installed apps:</source>
        <translation>Aplicações instaladas:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1299"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1328"/>
        <source>Total installed size:</source>
        <translation>Tamanho total instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Remove unused runtimes</source>
        <translation>Remover &apos;runtimes&apos; não utilizados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="623"/>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>Select all</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1500"/>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <location filename="../src/mainwindow.cpp" line="3945"/>
        <source>Console Output</source>
        <translation>Processamento</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1506"/>
        <source>Enter</source>
        <translation>Introduzir/Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1516"/>
        <source>Respond here, or just press Enter</source>
        <translation>Responder aqui ou premir Introduzir/Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1575"/>
        <location filename="../src/mainwindow.cpp" line="1979"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4325"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1581"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1600"/>
        <source>Quit application</source>
        <translation>Sair da aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1603"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1641"/>
        <source>About this application</source>
        <translation>Sobre esta aplicação</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1644"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1650"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1688"/>
        <source>Display help </source>
        <translation>Mostrar ajuda </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1691"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1697"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1713"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1719"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="477"/>
        <source>Uninstalling packages...</source>
        <translation>A desinstalar pacotes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="482"/>
        <source>Running pre-uninstall operations...</source>
        <translation>A executar operações pré-desinstalação...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="502"/>
        <source>Running post-uninstall operations...</source>
        <translation>A executar operações pós-desinstalação...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="519"/>
        <source>Refreshing sources...</source>
        <translation>A actualizar as origens...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <location filename="../src/mainwindow.cpp" line="2027"/>
        <location filename="../src/mainwindow.cpp" line="2169"/>
        <location filename="../src/mainwindow.cpp" line="2338"/>
        <location filename="../src/mainwindow.cpp" line="2415"/>
        <location filename="../src/mainwindow.cpp" line="2774"/>
        <location filename="../src/mainwindow.cpp" line="3018"/>
        <location filename="../src/mainwindow.cpp" line="3460"/>
        <location filename="../src/mainwindow.cpp" line="3477"/>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="3780"/>
        <location filename="../src/mainwindow.cpp" line="3831"/>
        <location filename="../src/mainwindow.cpp" line="4416"/>
        <location filename="../src/mainwindow.cpp" line="4505"/>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <location filename="../src/mainwindow.cpp" line="4635"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="533"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Houve um problema ao actualizar as origens. Algumas origens podem não ter fornecido actualizações. Para mais informação, ver: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="650"/>
        <location filename="../src/mainwindow.cpp" line="677"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Não é possível determinar a versão do Debian. Escolha a sua versão:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="683"/>
        <source>Debian Version</source>
        <translation>Versão do Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1232"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1238"/>
        <source>Please wait...</source>
        <translation>Aguardar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1788"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Está prestes a ser usado o repositório MX Test, cujos pacotes são disponibilizados sobretudo para serem testados. Há alguma probabilidade de os pacotes deste repositório danificarem o sistema, pelo que é sugerido que seja feita uma cópia de segurança (backup) do sistema e que seja instalado ou actualizado apenas um pacote de cada vez. Solicita-se que os resultados (execução sem problemas ou com problemas e quais) sejam comunicados no fórum (https://forum.mxlinux.org, em &apos;Select language&apos; escolher Portuguese, registar-se se ainda não registado, e ir para a secção Comunidade), para que seja feita uma re-avaliação dos pacotes antes de serem movidos para o repositório estável. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1797"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Está prestes a ser usado o repositório Debian Retroportados. Este repositório contém pacotes retirados da versão Debian &apos;testing&apos; (próxima versão oficial do Debian), adaptados e recompilados para uso na actual versão oficial (Debian &apos;stable&apos;) - sendo por isso designados de pacotes retroportados. Estes pacotes não foram tão extensivamente testados como os das versões estáveis do Debian e do MX; por isso, são disponibilizados &apos;como estão&apos;, com o risco de incompatibilidades com outros componentes do Debian &apos;stable&apos;. Usar com cuidado!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1805"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>O MX inclui este repositório de pacotes flatpak apenas para conveniência dos utilizadores, não sendo responsável pelo funcionamento dos próprios pacotes flatpak. Para mais informação (em inglês) consultar &apos;flatpaks&apos; no Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1813"/>
        <location filename="../src/mainwindow.cpp" line="4663"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1817"/>
        <source>Do not show this message again</source>
        <translation>Não mostrar esta mensagem novamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1976"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1992"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Foram selecionados os seguintes pacotes. Clique em Mostrar detalhes para obter a lista de alterações.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2028"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <location filename="../src/mainwindow.cpp" line="2416"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Sem ligação à Internet; não é possível descarregar a lista de pacotes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2031"/>
        <source>Installing packages...</source>
        <translation>A instalar pacotes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2094"/>
        <source>Post-processing...</source>
        <translation>Pós-processamento...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2126"/>
        <source>Pre-processing for </source>
        <translation>Pré-processando para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2141"/>
        <source>Installing </source>
        <translation>A instalar </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2148"/>
        <source>Post-processing for </source>
        <translation>Pós-processando para </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2339"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Ocorreu um erro ao descarregar ou gravar o ficheiro: %1. Verifique a sua ligação de internet e o espaço livre no seu disco</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2424"/>
        <source>Downloading package info...</source>
        <translation>A descarregar informação do pacote...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2775"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando ‘dpkg-query’ retornou um erro. Por favor, execute o comando ‘dpkg-query -W’ no terminal e verifique o resultado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3019"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando dpkg-query produziu um erro. Execute o comando ‘dpkg-query -W’ no Terminal e verifique o seu resultado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3154"/>
        <location filename="../src/mainwindow.cpp" line="3273"/>
        <location filename="../src/mainwindow.cpp" line="3302"/>
        <source>Package info</source>
        <translation>Informação do pacote</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3182"/>
        <location filename="../src/mainwindow.cpp" line="4574"/>
        <source>More &amp;info...</source>
        <translation>Mais &amp;informação...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3216"/>
        <source>Packages to be installed: </source>
        <translation>Pacotes a instalar: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <source>Done</source>
        <translation>Concluído</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3443"/>
        <location filename="../src/mainwindow.cpp" line="3456"/>
        <location filename="../src/mainwindow.cpp" line="3474"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="3611"/>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4413"/>
        <location filename="../src/mainwindow.cpp" line="4501"/>
        <location filename="../src/mainwindow.cpp" line="4532"/>
        <location filename="../src/mainwindow.cpp" line="4631"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Processing finished successfully.</source>
        <translation>Processamento terminado com êxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3452"/>
        <location filename="../src/mainwindow.cpp" line="4527"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3461"/>
        <location filename="../src/mainwindow.cpp" line="3478"/>
        <location filename="../src/mainwindow.cpp" line="4417"/>
        <location filename="../src/mainwindow.cpp" line="4506"/>
        <location filename="../src/mainwindow.cpp" line="4539"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Detectado problema ao instalar; ver informação no separador de processamento.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3488"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3489"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3491"/>
        <source>Package Installer for MX Linux</source>
        <translation>Gestor de Programas/Pacotes do MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3494"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3500"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3596"/>
        <location filename="../src/mainwindow.cpp" line="4624"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3602"/>
        <location filename="../src/mainwindow.cpp" line="4626"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3603"/>
        <location filename="../src/mainwindow.cpp" line="4627"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Foi encontrado um problema ao desinstalar. Ver no separador de processamento</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Success</source>
        <translation>Êxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Houve um problema ao desinstalar o programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3781"/>
        <location filename="../src/mainwindow.cpp" line="3832"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Erro ao descarregar lista de pacotes. Verificar as origens APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3880"/>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak not installed</source>
        <translation>Pacote flatpak não instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3881"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>O pacote flatpak não está instalado.
Continuar e instalar o pacote?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3926"/>
        <source>Flatpak was not installed</source>
        <translation>O pacote flatpak não estava instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3949"/>
        <source>Needs re-login</source>
        <translation>É necessário re-entrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3950"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Poderá ser necessário sair e re-entrar para que os itens fiquem visíveis no menu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4124"/>
        <location filename="../src/mainwindow.cpp" line="4236"/>
        <location filename="../src/mainwindow.cpp" line="4300"/>
        <source>Mark keep</source>
        <translation>Marcar para manter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <source>Select/deselect all upgradable</source>
        <translation>Selecionar/desselecionar tudo o que pode ser atualizado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4142"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Selecionar/desselecionar tudo o que pode ser removido automaticamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4238"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4445"/>
        <location filename="../src/mainwindow.cpp" line="4585"/>
        <source>Quit?</source>
        <translation>Sair?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4586"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Processo ainda em execução. Sair pode deixar o sistema num estado instável.&lt;p&gt;&lt;b&gt;Sair realmente do MX Instalador de Pacotes?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4278"/>
        <source>Reinstall</source>
        <translation>Reinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4636"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Problema detectado durante a última operação. Consultar o processamento no terminal/consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4664"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Operação potencialmente perigosa.
Verificar cuidadosamente a lista de pacotes a serem removidos.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Gerir repositórios remotos flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Para todos os utilizadores</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Para o presente utilizador</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>introduzir a URL do repositório remoto flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>para instalar uma aplicação, introduzir a localização do respectivo ficheiro .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Adicionar ou remover repositórios remotos flatpak ou instalar aplicações usando a URL ou o caminho para o respectivo ficheiro .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Remover repositório remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Adicionar repositório remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalar aplicação</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Não removível</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>O Flathub é o principal repositório remoto flatpak e não será removido</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Erro ao adicionar o repositório remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Não foi possível adicionar o repositório remoto - o comando resultou num erro. Verificar o endereço do repositório remoto e voltar a tentar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Êxito</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Repositório remoto adicionado com êxito</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Versão do repositório</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Instalados</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Informação</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Foi impossível carregar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registo de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Falha ao carregar registo de alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>A base de dados do Dpkg/apt está bloqueada por outro programa: %1
Fechar esse programa ou esperar que ele termine e tentar novamente.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>O MX-Instalador de Pacotes é usado para gestão dos pacotes de software do MX Linux
    - instala pacotes seleccionados de diferentes origens
    - instala pacotes do repositório de testes do MX (MX Test Repo)
    - instala pacotes do repositório Debian Retroportados (Debian Backports)
    - instala pacotes flatpak</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Ignorar verificação de estado on-line se for erradamente indicada falta de acesso à Internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O utilizador parece ser o root; para usar este programa, sair e voltar a entrar como utilizador normal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Este programa tem de ser executado como administrador.</translation>
    </message>
</context>
</TS>