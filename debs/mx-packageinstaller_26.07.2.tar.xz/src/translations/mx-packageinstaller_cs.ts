<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="cs">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="255"/>
        <source>Administrator Access Required</source>
        <translation>Vyžadován přístup správce</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="256"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Package</source>
        <translation>Balík</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="179"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="181"/>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="183"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="185"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>MX Package Installer</source>
        <translation>MX Instalátor softvéru </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Oblíbené aplikace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Spravovat oblíbené balíky&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <location filename="../src/mainwindow.ui" line="1580"/>
        <source>search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Instalované balíky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Povolené repozitáře</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Aktualizovat všechno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Nainstalováno:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Balíků  celkem:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Nainstalovat taky &quot;Doporučené&quot; balíky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Možné aktualizovat:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Skrýt knihovny a vývojářské balíky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <location filename="../src/mainwindow.ui" line="1590"/>
        <source>Refresh list</source>
        <translation>Obnovit seznam</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1532"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrovat balíky dle statusu.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4888"/>
        <source>All packages</source>
        <translation>Všechny balíky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4914"/>
        <source>Installed</source>
        <translation>Nainstalováno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4915"/>
        <source>Upgradable</source>
        <translation>Možné aktualizovat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4881"/>
        <location filename="../src/mainwindow.cpp" line="4916"/>
        <source>Not installed</source>
        <translation>Nenainstalováno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="4852"/>
        <location filename="../src/mainwindow.cpp" line="4917"/>
        <location filename="../src/mainwindow.cpp" line="4995"/>
        <location filename="../src/mainwindow.cpp" line="5086"/>
        <source>Autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Balík je možné aktualizovat, ve vybraném repozitáři je dostupná novější verze programu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>Testovací repozitář</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpaky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <source>For all users</source>
        <translation>Pro všechny uživatele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Pro současného uživatele</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Remote (repo):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4863"/>
        <source>All apps</source>
        <translation>Všechny aplikace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4869"/>
        <source>All runtimes</source>
        <translation>Všechny runtimy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4875"/>
        <source>All available</source>
        <translation>Všechny k dispozici</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4860"/>
        <source>Installed apps</source>
        <translation>Instalované aplikace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4857"/>
        <source>Installed runtimes</source>
        <translation>Nainstalované runtimy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4879"/>
        <source>All installed</source>
        <translation>Všechny nainstalované</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <location filename="../src/mainwindow.ui" line="1657"/>
        <source>Total items </source>
        <translation>Celkem položek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Instalované aplikace:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Rozšířené</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Celková instalovaná velikost:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Odebrat nevyužité runtimy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1535"/>
        <location filename="../src/mainwindow.ui" line="1539"/>
        <location filename="../src/mainwindow.cpp" line="4444"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1544"/>
        <location filename="../src/mainwindow.cpp" line="4359"/>
        <location filename="../src/mainwindow.cpp" line="4447"/>
        <location filename="../src/mainwindow.cpp" line="4449"/>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1619"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1698"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1721"/>
        <location filename="../src/mainwindow.cpp" line="3858"/>
        <location filename="../src/mainwindow.cpp" line="4224"/>
        <source>Console Output</source>
        <translation>Konzole</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Enter</source>
        <translation>Vložit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1737"/>
        <source>Respond here, or just press Enter</source>
        <translation>Odpovězte zde, nebo stiskněte Vložit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1796"/>
        <location filename="../src/mainwindow.cpp" line="1971"/>
        <location filename="../src/mainwindow.cpp" line="4653"/>
        <location filename="../src/mainwindow.cpp" line="4901"/>
        <location filename="../src/mainwindow.cpp" line="4912"/>
        <location filename="../src/mainwindow.cpp" line="5025"/>
        <location filename="../src/mainwindow.cpp" line="5065"/>
        <location filename="../src/mainwindow.cpp" line="5085"/>
        <location filename="../src/mainwindow.cpp" line="5126"/>
        <source>Install</source>
        <translation>Instalovat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1802"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1821"/>
        <source>Quit application</source>
        <translation>Ukončit aplikaci</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1824"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1830"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1862"/>
        <source>About this application</source>
        <translation>O této aplikaci</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1865"/>
        <source>About...</source>
        <translation>O programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1871"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1909"/>
        <source>Display help </source>
        <translation>Zobrazit nápovědu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1912"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1918"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1934"/>
        <source>Uninstall</source>
        <translation>Odinstalovat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1940"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="559"/>
        <source>Uninstalling packages...</source>
        <translation>Odstraňování balíků...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="564"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Spouštění před-odinstalačních operací...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Running post-uninstall operations...</source>
        <translation>Spouštění post-odinstalačních operací...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>Refreshing sources...</source>
        <translation>Aktualizace zdrojů...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <location filename="../src/mainwindow.cpp" line="2023"/>
        <location filename="../src/mainwindow.cpp" line="2168"/>
        <location filename="../src/mainwindow.cpp" line="2358"/>
        <location filename="../src/mainwindow.cpp" line="2436"/>
        <location filename="../src/mainwindow.cpp" line="2814"/>
        <location filename="../src/mainwindow.cpp" line="3052"/>
        <location filename="../src/mainwindow.cpp" line="3546"/>
        <location filename="../src/mainwindow.cpp" line="3624"/>
        <location filename="../src/mainwindow.cpp" line="3785"/>
        <location filename="../src/mainwindow.cpp" line="3848"/>
        <location filename="../src/mainwindow.cpp" line="4019"/>
        <location filename="../src/mainwindow.cpp" line="4070"/>
        <location filename="../src/mainwindow.cpp" line="4243"/>
        <location filename="../src/mainwindow.cpp" line="5217"/>
        <location filename="../src/mainwindow.cpp" line="5318"/>
        <location filename="../src/mainwindow.cpp" line="5353"/>
        <location filename="../src/mainwindow.cpp" line="5452"/>
        <location filename="../src/mainwindow.cpp" line="5492"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="615"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Při aktualizaci zdrojů se vyskytla chyba. Některé zdroje nemuseli být zaktualizované. Pro víc informací zkontrolujte:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="727"/>
        <location filename="../src/mainwindow.cpp" line="754"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1225"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1231"/>
        <source>Please wait...</source>
        <translation>Prosím vyčkejte...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1773"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Chystáte se použít zdroj Testovací repozitář, který obsahuje softvérové balíky určené pouze pro jejich testování. Je možné, že tyto ovlivní stabilitu vášho systému. Je proto doporučeno zazálohovat systémová nastavení a instalovat nebo aktualizovat balíky jenotlivě.  Prosíme o poskytnutí zpětné vazby ve fóru aby mohli být jednotlivé balíky správně vyhodnocené před jejich přesunem do Hlavního repozitáře.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1782"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Chystáte se použít zdroj Debian Backports, který obsahuje softvérové balíky převzaté z budoucího vydání Debian-u (nazývaný taky &apos;testovací větev&apos;), přizpůsobené pro použití v stabilním Debian-u. Tyto balíky nemohou být otestovány tak rozsáhle jako balíky ze stabilní větve Debian-u a MX Linuxu a jsou poskytovány tak-jak-jsou, s rizikem ztráty kompatibility s jinými komponenty ze stabilní větve Debian-u. Používejte se vší opatrností!  </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1790"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>Repozitář flatpaků je zde pouze pro vaše pohodlí a vývojáři MX Linux nezodpovídají za funkčnost jednotlivých flatpaků. Pro další informace si můžete dohledat flatpaky třeba ve Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1798"/>
        <location filename="../src/mainwindow.cpp" line="5482"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Do not show this message again</source>
        <translation>Znovu nezobrazovat tuto zprávu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1968"/>
        <source>Remove</source>
        <translation>Odstranit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1984"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Byly vybrány nasledující balíky. Seznam změn zobrazíte kliknutím na Ukázat podrobnosti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2024"/>
        <location filename="../src/mainwindow.cpp" line="2169"/>
        <location filename="../src/mainwindow.cpp" line="2437"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Není k dispozici internetové připojení, stažení seznamu balíků nebude možné</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2027"/>
        <source>Installing packages...</source>
        <translation>Instalace balíků...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <source>Post-processing...</source>
        <translation>Dokončování...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2122"/>
        <source>Pre-processing for </source>
        <translation>Příprava pro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2137"/>
        <source>Installing </source>
        <translation>Instalace</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2147"/>
        <source>Post-processing for </source>
        <translation>Dokončování pro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2359"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2445"/>
        <source>Downloading package info...</source>
        <translation>Stahuji informace o balících...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2815"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3053"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3187"/>
        <location filename="../src/mainwindow.cpp" line="3303"/>
        <location filename="../src/mainwindow.cpp" line="3351"/>
        <source>Package info</source>
        <translation>Informace o balíku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3219"/>
        <location filename="../src/mainwindow.cpp" line="5389"/>
        <source>More &amp;info...</source>
        <translation>Vic info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3244"/>
        <source>Packages to be installed: </source>
        <translation>Balíky k instalaci:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3542"/>
        <location filename="../src/mainwindow.cpp" line="3599"/>
        <location filename="../src/mainwindow.cpp" line="3621"/>
        <location filename="../src/mainwindow.cpp" line="3781"/>
        <location filename="../src/mainwindow.cpp" line="3827"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <location filename="../src/mainwindow.cpp" line="5214"/>
        <location filename="../src/mainwindow.cpp" line="5314"/>
        <location filename="../src/mainwindow.cpp" line="5347"/>
        <location filename="../src/mainwindow.cpp" line="5448"/>
        <source>Done</source>
        <translation>Hotovo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3542"/>
        <location filename="../src/mainwindow.cpp" line="3599"/>
        <location filename="../src/mainwindow.cpp" line="3621"/>
        <location filename="../src/mainwindow.cpp" line="3781"/>
        <location filename="../src/mainwindow.cpp" line="3827"/>
        <location filename="../src/mainwindow.cpp" line="3845"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <location filename="../src/mainwindow.cpp" line="5214"/>
        <location filename="../src/mainwindow.cpp" line="5314"/>
        <location filename="../src/mainwindow.cpp" line="5347"/>
        <location filename="../src/mainwindow.cpp" line="5448"/>
        <location filename="../src/mainwindow.cpp" line="5489"/>
        <source>Processing finished successfully.</source>
        <translation>Zpracování bylo úspěšně dokončeno.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3537"/>
        <location filename="../src/mainwindow.cpp" line="3597"/>
        <location filename="../src/mainwindow.cpp" line="5342"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3547"/>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <location filename="../src/mainwindow.cpp" line="5218"/>
        <location filename="../src/mainwindow.cpp" line="5319"/>
        <location filename="../src/mainwindow.cpp" line="5354"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Během instalace byl zjištěn problém, zkontrolujte výstup konzole.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3566"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3567"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3578"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3581"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3602"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3637"/>
        <source>About %1</source>
        <translation>O programu %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3638"/>
        <source>Version: </source>
        <translation>Verze:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3640"/>
        <source>Package Installer for MX Linux</source>
        <translation>Program pro instalaci dodatečného softvéru pro MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3642"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Vlastnická práva (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3643"/>
        <source>%1 License</source>
        <translation>Licence %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3649"/>
        <source>%1 Help</source>
        <translation>Nápověda %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3762"/>
        <location filename="../src/mainwindow.cpp" line="5441"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3771"/>
        <location filename="../src/mainwindow.cpp" line="3825"/>
        <location filename="../src/mainwindow.cpp" line="5443"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3772"/>
        <location filename="../src/mainwindow.cpp" line="5444"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3785"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Při odinstalaci došlo k potížím, zkontrolujte výstup</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3805"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3806"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3830"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3845"/>
        <location filename="../src/mainwindow.cpp" line="5489"/>
        <source>Success</source>
        <translation>Úspěch!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3848"/>
        <location filename="../src/mainwindow.cpp" line="5492"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Při odinstalaci programu došlo k potížím</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4020"/>
        <location filename="../src/mainwindow.cpp" line="4071"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Nepodařilo se stáhnout seznam balíčků. Prosím, zkontrolujte své zdroje APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4151"/>
        <location filename="../src/mainwindow.cpp" line="4205"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak není nainstalován</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4152"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak zatím není nainstalován.
Chcete pokračovat k instalaci?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4205"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak nebyl nainstalován</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4228"/>
        <location filename="../src/mainwindow.cpp" line="4617"/>
        <source>Needs re-login</source>
        <translation>Nutné nové přihlášení</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4229"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Pro zobrazení nově nainstalovaných položek v menu bude asi zapotřebí se odhlásit a pak znovu přihlásit.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4472"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4472"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4515"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4539"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4604"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4609"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4613"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4694"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4901"/>
        <location filename="../src/mainwindow.cpp" line="4912"/>
        <location filename="../src/mainwindow.cpp" line="5023"/>
        <location filename="../src/mainwindow.cpp" line="5087"/>
        <source>Mark keep</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4928"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4929"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5025"/>
        <location filename="../src/mainwindow.cpp" line="5085"/>
        <source>Upgrade</source>
        <translation>Aktualizovat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5248"/>
        <location filename="../src/mainwindow.cpp" line="5400"/>
        <source>Quit?</source>
        <translation>Ukončit?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5249"/>
        <location filename="../src/mainwindow.cpp" line="5401"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Proces je pořád spuštěn, ukončení může zanechat systém v nestabilním stavu.&lt;p&gt;&lt;b&gt;Opravdu chcete aplikaci ukončit?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5065"/>
        <source>Reinstall</source>
        <translation>Přeinstalovat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4618"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4686"/>
        <location filename="../src/mainwindow.cpp" line="5311"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5453"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Během poslední operace se vyskytl problém, prohlédněte Konzoli.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5483"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Potencionálně nebezpečná operace.
Prosíme pozorně si zkontrolujte seznam aplikací k odinstalaci.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Nastavit Flatpak Remotes</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Pro všechny uživatele</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Pro současného uživatele</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>zadejte Flatpak remote URL sem</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>zadejte Flatpakref lokaci pro instalaci aplikace sem</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Zde můžete přidat nebo odebrat flatpak remote (repozitáře), nebo nainstalovat aplikace použitím flatpakref URL nebo přímé cesty</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Odebrat remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Přidat remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalovat aplikaci</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Nelze odebrat</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub je hlavním Flatpak repozitářem a nemůže být odstraněn</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>Chyba při přidání remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Remote nebyl přidán - příkaz skončil chybou. Zkontrolujte prosím adresu remote a zkuste to znovu.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Úspěch!</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>Remote byl přidán</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Balík</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Nainstalováno</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Balík</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licence</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Protokol změn</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Zavřít</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="59"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="60"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Instalátor softvéru je nástroj používaný pro správu balíčků na MX Linux
 - instaluje oblíbené programy z různých zdrojů
 - instaluje programy z Testovacího repozitáře
 - instaluje programy z repozitáře Debian Backports
 - instaluje balíčky ve formátu Flatpak</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Přeskočte online kontrolu, pokud nesprávně hlásí chybějící přístup k internetu.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Spuštěno pod účtem root-a, odhlašte se a přihlašte jako bězný uživatel.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Tento program musíte spustit s oprávněním správce.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Balík</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="148"/>
        <source>Version</source>
        <translation>Verze</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="150"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="152"/>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="154"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
</context>
</TS>