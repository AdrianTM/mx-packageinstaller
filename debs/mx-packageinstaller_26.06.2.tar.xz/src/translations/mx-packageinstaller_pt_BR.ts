<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>O acesso com as permissões de administrador é necessário</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operação requer as permissões ou os privilégios de administrador. Por favor, reinicie o programa e digite a sua senha quando for solicitada.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="152"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="154"/>
        <source>Full Name</source>
        <translation>Nome Completo</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="156"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="158"/>
        <source>Branch</source>
        <translation>Filial</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="160"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="307"/>
        <source>MX Package Installer</source>
        <translation>Instalador e Desinstalador de Programas do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Programas Populares</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Instalador e Desinstalador de Programas do MX Linux&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Esta ferramenta é um gerenciador de pacotes do MX Linux, o nome original em idioma inglês é ‘&lt;b&gt;MX Package Installer&lt;/b&gt;’. &lt;br&gt;Os itens sombreados ou esmaecidos ou que possuem uma sinalização à esquerda do nome indicam que o programa já está instalado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <location filename="../src/mainwindow.ui" line="1580"/>
        <source>search</source>
        <translation>Digite aqui para pesquisar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Pacotes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Repositórios Ativados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remover todos os pacotes que estão marcados como ‘autorremovível’ (autoremovable). Se você quiser gerenciá-los, selecione a opção ‘Autorremovíveis’ na caixa de seleção suspensa.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Pacotes Autorremovíveis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Atualizar Todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Total de pacotes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Instalar também os pacotes “recomendados”</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Atualizáveis:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Ocultar os pacotes das bibliotecas e os pacotes do desenvolvedor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <location filename="../src/mainwindow.ui" line="1590"/>
        <source>Refresh list</source>
        <translation>Atualizar a lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1532"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar os pacotes de acordo com o seu estado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4762"/>
        <source>All packages</source>
        <translation>Todos os pacotes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4788"/>
        <source>Installed</source>
        <translation>Instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4789"/>
        <source>Upgradable</source>
        <translation>Atualizáveis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4755"/>
        <location filename="../src/mainwindow.cpp" line="4790"/>
        <source>Not installed</source>
        <translation>Não instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3603"/>
        <location filename="../src/mainwindow.cpp" line="4726"/>
        <location filename="../src/mainwindow.cpp" line="4791"/>
        <location filename="../src/mainwindow.cpp" line="4870"/>
        <location filename="../src/mainwindow.cpp" line="4961"/>
        <source>Autoremovable</source>
        <translation>Autorremovíveis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Pacote atualizável. A versão mais recente está disponível no repositório selecionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>Repositório de Teste do MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Repositório Retroportado do Debian (Backports)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>For all users</source>
        <translation>Para todos os usuários</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Para o usuário atual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Repositório remoto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4737"/>
        <source>All apps</source>
        <translation>Todos os aplicativos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4743"/>
        <source>All runtimes</source>
        <translation>Todas as versões</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4749"/>
        <source>All available</source>
        <translation>Todos os disponíveis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4734"/>
        <source>Installed apps</source>
        <translation>Aplicativos Instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4731"/>
        <source>Installed runtimes</source>
        <translation>Versões dos pacotes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4753"/>
        <source>All installed</source>
        <translation>Todos instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <location filename="../src/mainwindow.ui" line="1657"/>
        <source>Total items </source>
        <translation>Total de itens:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Aplicativos instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Avançado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Espaço utilizado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Remover as versões que não estiverem sendo utilizadas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Selecionar tudo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation>Apenas os pacotes dos repositórios do MX ou do Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1535"/>
        <location filename="../src/mainwindow.ui" line="1539"/>
        <location filename="../src/mainwindow.cpp" line="4367"/>
        <location filename="../src/mainwindow.cpp" line="4546"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1544"/>
        <location filename="../src/mainwindow.cpp" line="4282"/>
        <location filename="../src/mainwindow.cpp" line="4370"/>
        <location filename="../src/mainwindow.cpp" line="4372"/>
        <location filename="../src/mainwindow.cpp" line="4612"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1619"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1698"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1721"/>
        <location filename="../src/mainwindow.cpp" line="3824"/>
        <location filename="../src/mainwindow.cpp" line="4147"/>
        <source>Console Output</source>
        <translation>Resultados no Console/Terminal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1737"/>
        <source>Respond here, or just press Enter</source>
        <translation>Responda aqui ou apenas pressione a tecla ‘Enter’</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1796"/>
        <location filename="../src/mainwindow.cpp" line="2026"/>
        <location filename="../src/mainwindow.cpp" line="4531"/>
        <location filename="../src/mainwindow.cpp" line="4775"/>
        <location filename="../src/mainwindow.cpp" line="4786"/>
        <location filename="../src/mainwindow.cpp" line="4900"/>
        <location filename="../src/mainwindow.cpp" line="4940"/>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <location filename="../src/mainwindow.cpp" line="4987"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1802"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1821"/>
        <source>Quit application</source>
        <translation>Sair do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1824"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1830"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1862"/>
        <source>About this application</source>
        <translation>Sobre este aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1865"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1871"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1909"/>
        <source>Display help </source>
        <translation>Exibir ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1912"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1918"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1934"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1940"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="511"/>
        <source>Uninstalling packages...</source>
        <translation>Desinstalando os pacotes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="516"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Executando as operações da pré-desinstalação...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="536"/>
        <source>Running post-uninstall operations...</source>
        <translation>Executando as operações da pós-desinstalação...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="553"/>
        <source>Refreshing sources...</source>
        <translation>Atualizando as fontes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="566"/>
        <location filename="../src/mainwindow.cpp" line="2078"/>
        <location filename="../src/mainwindow.cpp" line="2216"/>
        <location filename="../src/mainwindow.cpp" line="2384"/>
        <location filename="../src/mainwindow.cpp" line="2461"/>
        <location filename="../src/mainwindow.cpp" line="2823"/>
        <location filename="../src/mainwindow.cpp" line="3067"/>
        <location filename="../src/mainwindow.cpp" line="3537"/>
        <location filename="../src/mainwindow.cpp" line="3613"/>
        <location filename="../src/mainwindow.cpp" line="3755"/>
        <location filename="../src/mainwindow.cpp" line="3816"/>
        <location filename="../src/mainwindow.cpp" line="3982"/>
        <location filename="../src/mainwindow.cpp" line="4033"/>
        <location filename="../src/mainwindow.cpp" line="4166"/>
        <location filename="../src/mainwindow.cpp" line="5083"/>
        <location filename="../src/mainwindow.cpp" line="5182"/>
        <location filename="../src/mainwindow.cpp" line="5217"/>
        <location filename="../src/mainwindow.cpp" line="5316"/>
        <location filename="../src/mainwindow.cpp" line="5354"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="567"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Houve um problema ao atualizar as fontes/origens. Algumas fontes podem não ter fornecido atualizações. Para obter mais informação, verifique:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <location filename="../src/mainwindow.cpp" line="712"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Não foi possível determinar qual é a versão do Debian.
Por favor, selecione a sua versão:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="718"/>
        <source>Debian Version</source>
        <translation>Versão do Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1275"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1281"/>
        <source>Please wait...</source>
        <translation>Por favor, espere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1829"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Você está prestes a utilizar o Repositório de Testes do MX que disponibiliza os pacotes apenas para teste. É possível que eles quebrem/danifiquem o seu sistema operacional. Por isso, é recomendado que você faça uma cópia de segurança (backup) do seu sistema operacional e instale ou atualize apenas um pacote de cada vez. Se for possível, nos informe no fórum, como foi a sua experiência com o pacote, para que ele seja avaliado e encaminhado para o repositório principal (estável) se for qualificado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1838"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Você está prestes a utilizar o repositório do ‘Debian Backports’ (atualizações retroportadas), que contém pacotes retirados do próximo lançamento do Debian (chamado de ‘teste’ ou ‘testing’), adaptados e recompilados para o uso na versão atual do Debian ‘estável’ ou ‘stable’. Estes pacotes não foram testados tão extensivamente como os das versões estáveis do Debian e do MX Linux, são fornecidos no estado em que se encontram ou ‘como estão’, possuem o risco de incompatibilidades com outros componentes do Debian estável. Por tanto, utilize com muito cuidado!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1846"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>O repositório do MX Linux inclui os pacotes do tipo ‘Flatpaks’, são destinados apenas para a facilitar o acesso dos usuários a este tipo de pacote. Nós não somos responsáveis pelo funcionamento dos pacotes do tipo ‘Flatpaks’. Para obter mais informações, por favor, consulte ‘Flatpaks’ no Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1854"/>
        <location filename="../src/mainwindow.cpp" line="5344"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1858"/>
        <source>Do not show this message again</source>
        <translation>Não exibir esta mensagem novamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2023"/>
        <source>Remove</source>
        <translation>Remover</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Os seguintes pacotes foram selecionados. Clique na opção ‘Exibir Detalhes‘ para exibir a lista de alterações.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <location filename="../src/mainwindow.cpp" line="2217"/>
        <location filename="../src/mainwindow.cpp" line="2462"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Sem conexão com a internet, não será possível baixar/descarregar/transferir a lista de pacotes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2082"/>
        <source>Installing packages...</source>
        <translation>Instalando os pacotes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2141"/>
        <source>Post-processing...</source>
        <translation>Pós-processamento...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2173"/>
        <source>Pre-processing for </source>
        <translation>Pré-processamento para</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2188"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2195"/>
        <source>Post-processing for </source>
        <translation>Pós-processamento para</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2385"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Ocorreu um erro ao baixar ou gravar o arquivo %1. Por favor, verifique a sua conexão com a internet e se você possui espaço livre em sua unidade de armazenamento</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2470"/>
        <source>Downloading package info...</source>
        <translation>Baixando as informações do pacote...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2824"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando ‘dpkg-query’ retornou um erro. Por favor, execute o comando ‘dpkg-query -W’ no Emulador de Terminal e verifique o resultado da saída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3068"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando ‘dpkg-query’ retornou com uma mensagem de erro. Por favor, execute o comando ‘dpkg-query -W’ no Emulador de Terminal e verifique o resultado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3202"/>
        <location filename="../src/mainwindow.cpp" line="3325"/>
        <location filename="../src/mainwindow.cpp" line="3359"/>
        <source>Package info</source>
        <translation>Informações do pacote</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3232"/>
        <location filename="../src/mainwindow.cpp" line="5253"/>
        <source>More &amp;info...</source>
        <translation>Mais &amp;informações...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3266"/>
        <source>Packages to be installed: </source>
        <translation>Pacotes a serem instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3533"/>
        <location filename="../src/mainwindow.cpp" line="3590"/>
        <location filename="../src/mainwindow.cpp" line="3610"/>
        <location filename="../src/mainwindow.cpp" line="3724"/>
        <location filename="../src/mainwindow.cpp" line="3751"/>
        <location filename="../src/mainwindow.cpp" line="3797"/>
        <location filename="../src/mainwindow.cpp" line="4566"/>
        <location filename="../src/mainwindow.cpp" line="5080"/>
        <location filename="../src/mainwindow.cpp" line="5178"/>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <location filename="../src/mainwindow.cpp" line="5312"/>
        <source>Done</source>
        <translation>Concluído</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3533"/>
        <location filename="../src/mainwindow.cpp" line="3590"/>
        <location filename="../src/mainwindow.cpp" line="3610"/>
        <location filename="../src/mainwindow.cpp" line="3724"/>
        <location filename="../src/mainwindow.cpp" line="3751"/>
        <location filename="../src/mainwindow.cpp" line="3797"/>
        <location filename="../src/mainwindow.cpp" line="3813"/>
        <location filename="../src/mainwindow.cpp" line="4566"/>
        <location filename="../src/mainwindow.cpp" line="5080"/>
        <location filename="../src/mainwindow.cpp" line="5178"/>
        <location filename="../src/mainwindow.cpp" line="5211"/>
        <location filename="../src/mainwindow.cpp" line="5312"/>
        <location filename="../src/mainwindow.cpp" line="5351"/>
        <source>Processing finished successfully.</source>
        <translation>O processamento foi concluído com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3528"/>
        <location filename="../src/mainwindow.cpp" line="3588"/>
        <location filename="../src/mainwindow.cpp" line="5206"/>
        <source>Install complete.</source>
        <translation>A instalação foi concluída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3538"/>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="5084"/>
        <location filename="../src/mainwindow.cpp" line="5183"/>
        <location filename="../src/mainwindow.cpp" line="5218"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Foi detectado um problema durante a instalação, por favor, verifique as informações de saída no Console/Terminal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3557"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3558"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3569"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3572"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3593"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3624"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3625"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3627"/>
        <source>Package Installer for MX Linux</source>
        <translation>Instalador e Desinstalador de Programas do MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3629"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3732"/>
        <location filename="../src/mainwindow.cpp" line="5305"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Desinstalando os pacotes flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3741"/>
        <location filename="../src/mainwindow.cpp" line="3795"/>
        <location filename="../src/mainwindow.cpp" line="5307"/>
        <source>Uninstall complete.</source>
        <translation>A remoção foi concluída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3742"/>
        <location filename="../src/mainwindow.cpp" line="5308"/>
        <source>Refreshing flatpaks...</source>
        <translation>Atualizando os flatpaks...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3755"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Ocorreu um problema ao desinstalar o pacote, por favor, verifique o resultado do processo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3775"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3776"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3800"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3813"/>
        <location filename="../src/mainwindow.cpp" line="5351"/>
        <source>Success</source>
        <translation>O processo foi concluído com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3816"/>
        <location filename="../src/mainwindow.cpp" line="5354"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Ocorreu um problema ao desinstalar o programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3983"/>
        <location filename="../src/mainwindow.cpp" line="4034"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Não foi possível baixar a lista de pacotes atualizada. Por favor, verifique as suas fontes do APT na pasta /etc/apt/sources.list.d.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4082"/>
        <location filename="../src/mainwindow.cpp" line="4128"/>
        <source>Flatpak not installed</source>
        <translation>O Flatpak não está instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4083"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>O pacote Flatpak não está instalado.
Você gostaria de instalá-lo agora?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4128"/>
        <source>Flatpak was not installed</source>
        <translation>O Flatpak não foi instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4151"/>
        <location filename="../src/mainwindow.cpp" line="4495"/>
        <source>Needs re-login</source>
        <translation>É preciso sair da sessão e entrar novamente com o seu usuário e senha</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4152"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Você pode precisar sair da sessão e entrar novamente com o seu usuário e senha para ver os novos itens instalados nos menus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4395"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4395"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4431"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4482"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4487"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4491"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4775"/>
        <location filename="../src/mainwindow.cpp" line="4786"/>
        <location filename="../src/mainwindow.cpp" line="4898"/>
        <location filename="../src/mainwindow.cpp" line="4962"/>
        <source>Mark keep</source>
        <translation>Marcar para manter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4803"/>
        <source>Select/deselect all upgradable</source>
        <translation>Selecionar ou desselecionar todos os pacotes que podem ser atualizados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4804"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Selecionar ou desselecionar todos os pacotes que podem ser removidos automaticamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4900"/>
        <location filename="../src/mainwindow.cpp" line="4960"/>
        <source>Upgrade</source>
        <translation>Atualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5112"/>
        <location filename="../src/mainwindow.cpp" line="5264"/>
        <source>Quit?</source>
        <translation>Você quer sair?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5113"/>
        <location filename="../src/mainwindow.cpp" line="5265"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>O processo ainda está em execução, se você finalizar agora pode deixar o seu sistema operacional em um estado inutilizável.&lt;p&gt;&lt;b&gt;Você tem certeza que quer fechar o Instalador e Desinstalador de Programas do MX?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4940"/>
        <source>Reinstall</source>
        <translation>Reinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4496"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4563"/>
        <location filename="../src/mainwindow.cpp" line="5175"/>
        <source>Update complete.</source>
        <translation>A atualização foi concluída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5317"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Um problema foi detectado durante a última operação. Por favor, inspecione a saída do Console/Terminal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5345"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>A operação é potencialmente perigosa.
Por favor, verifique cuidadosamente a lista de pacotes a ser removida.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Gerenciar os Repositórios Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Para todos os usuários</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Para este usuário</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>digite o endereço do repositório Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>digite o endereço Flatpakref para instalar um aplicativo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Adicione ou remova os repositórios flatpak, ou instale aplicativos utilizando o endereço flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Remover o repositório</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Adicionar o repositório</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalar o aplicativo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Não é removível</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>O Flathub é o repositório principal dos Flatpak’s e não pode ser removido</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>Ocorreu um erro ao adicionar o repositório</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Não foi possível adicionar o repositório - o comando retornou um erro. Por favor, verifique o endereço do repositório e tente novamente.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Sucesso</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>O repositório foi adicionado com sucesso</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Versão do Repositório</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Instalados</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Informações</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Não foi possível carregar o %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Relatório de alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Não foi possível carregar o registro das alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>O banco de dados do dpkg/apt está bloqueado por outro programa: %1
Feche o outro programa gerenciador de pacotes ou espere até que o processamento termine e tente novamente.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>O Instalador e Desinstalador de Programas do MX, o nome original em idioma Inglês é ‘MX Package Installer’, é uma ferramenta utilizada para gerenciar os aplicativos ou pacotes no MX Linux
    - instala programas aplicativos de diferentes fontes
    - instala programas aplicativos do repositório de teste MX
    - instala programas aplicativos do repositório retroportado do Debian (Backports)
    - instala programas aplicativos com o formato Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Ignorar a verificação de conexão com a internet se for relatado falsamente de que não há conexão com a internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Ao que parece, você está acessando com o usuário ‘root’ (administrador). Por favor, saia da sessão e entre novamente com o usuário normal para utilizar este programa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Você tem que executar este programa com o usuário administrador.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Pacote</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="148"/>
        <source>Version</source>
        <translation>Versão</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="150"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="152"/>
        <source>Notes</source>
        <translation>Observações</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="154"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
</context>
</TS>