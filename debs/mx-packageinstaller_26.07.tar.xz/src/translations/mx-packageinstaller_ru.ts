<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Пожалуйста, перезапустите приложение и введите пароль при появлении соответствующего запроса.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="176"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="178"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="180"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="182"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="184"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="309"/>
        <source>MX Package Installer</source>
        <translation>MX Установщик пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Популярные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Управление популярными пакетами&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <location filename="../src/mainwindow.ui" line="1580"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Установленные пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Включить репозитории</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Удалить все пакеты помеченные как &amp;quot;авто-удаляемые&amp;quot;. Чтобы управлять ими, выберите &quot;Авто-удаляемые&quot; в раскрывающемся списке.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Автоматически удалить пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Обновить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Установлено:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Всего пакетов:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Устанавливать рекомендованные пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Доступно обновление:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Скрыть библиотеки и пакеты для разработчиков</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <location filename="../src/mainwindow.ui" line="1590"/>
        <source>Refresh list</source>
        <translation>Обновить список</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1532"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Фильтровать пакеты в зависимости от их статуса.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4696"/>
        <source>All packages</source>
        <translation>Все пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4722"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4723"/>
        <source>Upgradable</source>
        <translation>Доступно обновление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <location filename="../src/mainwindow.cpp" line="4724"/>
        <source>Not installed</source>
        <translation>Не установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3507"/>
        <location filename="../src/mainwindow.cpp" line="4660"/>
        <location filename="../src/mainwindow.cpp" line="4725"/>
        <location filename="../src/mainwindow.cpp" line="4804"/>
        <location filename="../src/mainwindow.cpp" line="4895"/>
        <source>Autoremovable</source>
        <translation>Авто-удаляемые</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Обновляемый пакет. Более новая версия доступна в выбранном репозитории.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX тестовый репозиторий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Бэкпорты Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Флатпак</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <location filename="../src/mainwindow.cpp" line="291"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Внешний репозиторий:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4671"/>
        <source>All apps</source>
        <translation>Все приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4677"/>
        <source>All runtimes</source>
        <translation>Все среды времени выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4683"/>
        <source>All available</source>
        <translation>Все доступные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Installed apps</source>
        <translation>Установленные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4665"/>
        <source>Installed runtimes</source>
        <translation>Установленные рантаймы</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4687"/>
        <source>All installed</source>
        <translation>Все установленные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <location filename="../src/mainwindow.ui" line="1657"/>
        <source>Total items </source>
        <translation>Всего элементов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Установленные приложения:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Общий размер установленного:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Удалить ненужные среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Выделить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1535"/>
        <location filename="../src/mainwindow.ui" line="1539"/>
        <location filename="../src/mainwindow.cpp" line="4271"/>
        <location filename="../src/mainwindow.cpp" line="4480"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1544"/>
        <location filename="../src/mainwindow.cpp" line="4186"/>
        <location filename="../src/mainwindow.cpp" line="4274"/>
        <location filename="../src/mainwindow.cpp" line="4276"/>
        <location filename="../src/mainwindow.cpp" line="4546"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1619"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1698"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1721"/>
        <location filename="../src/mainwindow.cpp" line="3728"/>
        <location filename="../src/mainwindow.cpp" line="4051"/>
        <source>Console Output</source>
        <translation>Вывод консоли</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1737"/>
        <source>Respond here, or just press Enter</source>
        <translation>Ответьте здесь или просто нажмите Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1796"/>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <location filename="../src/mainwindow.cpp" line="4709"/>
        <location filename="../src/mainwindow.cpp" line="4720"/>
        <location filename="../src/mainwindow.cpp" line="4834"/>
        <location filename="../src/mainwindow.cpp" line="4874"/>
        <location filename="../src/mainwindow.cpp" line="4894"/>
        <location filename="../src/mainwindow.cpp" line="4921"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1802"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1821"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1824"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1830"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1862"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1865"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1871"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1909"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1912"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1918"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1934"/>
        <source>Uninstall</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1940"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="513"/>
        <source>Uninstalling packages...</source>
        <translation>Удаление пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="518"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Выполняются предварительные действия удаления...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="538"/>
        <source>Running post-uninstall operations...</source>
        <translation>Действия, предусмотренные после деинсталляции, теперь выполняются...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="555"/>
        <source>Refreshing sources...</source>
        <translation>Обновляются источники...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="568"/>
        <location filename="../src/mainwindow.cpp" line="1981"/>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <location filename="../src/mainwindow.cpp" line="2287"/>
        <location filename="../src/mainwindow.cpp" line="2364"/>
        <location filename="../src/mainwindow.cpp" line="2726"/>
        <location filename="../src/mainwindow.cpp" line="2970"/>
        <location filename="../src/mainwindow.cpp" line="3441"/>
        <location filename="../src/mainwindow.cpp" line="3517"/>
        <location filename="../src/mainwindow.cpp" line="3659"/>
        <location filename="../src/mainwindow.cpp" line="3720"/>
        <location filename="../src/mainwindow.cpp" line="3886"/>
        <location filename="../src/mainwindow.cpp" line="3937"/>
        <location filename="../src/mainwindow.cpp" line="4070"/>
        <location filename="../src/mainwindow.cpp" line="5017"/>
        <location filename="../src/mainwindow.cpp" line="5116"/>
        <location filename="../src/mainwindow.cpp" line="5151"/>
        <location filename="../src/mainwindow.cpp" line="5250"/>
        <location filename="../src/mainwindow.cpp" line="5288"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="569"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Возникла проблема при обновлении источников. Возможно, некоторые источники не предоставили обновления. Для подробной информации проверьте:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="681"/>
        <location filename="../src/mainwindow.cpp" line="708"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Не удалось определить версию Debian. Выберите вашу версию:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="714"/>
        <source>Debian Version</source>
        <translation>Версия Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1178"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Please wait...</source>
        <translation>Пожалуйста, ждите...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1732"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Вы собираетесь подключить репозиторий MX Test, пакеты которого представлены только для тестирования. Они могут нарушить работу вашей системы, поэтому рекомендуется сделать резервную копию системы и устанавливать по одному пакету за раз. Пожалуйста, оставьте отчёт на форуме для того, чтобы пакет был дополнительно оценён до переноса в основной репозиторий.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1741"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Вы собираетесь использовать Debian Backports, который содержит пакеты, взятые из следующего выпуска Debian (именуемого «testing»), скорректированные и перекомпилированные для использования на Debian stable. Они не могли быть проверены так хорошо, как в стабильных версиях Debian и MX Linux, и предоставляются на основании «как есть» с риском несовместимости с другими компонентами в Debian stable. Используйте с осторожностью!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1749"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux включает этот репозиторий флатпаков только для удобства пользователей и не несёт ответственности за их функционирование. Подробнее о флатпаках в Вики.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1757"/>
        <location filename="../src/mainwindow.cpp" line="5278"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1761"/>
        <source>Do not show this message again</source>
        <translation>Больше не показывать это окно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1926"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1942"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Следующие пакеты были выбраны. Щёлкните на &quot;Показать подробности&quot; для просмотра списка изменений.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1982"/>
        <location filename="../src/mainwindow.cpp" line="2120"/>
        <location filename="../src/mainwindow.cpp" line="2365"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Интернет недоступен, невозможно загрузить список пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1985"/>
        <source>Installing packages...</source>
        <translation>Установка пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2044"/>
        <source>Post-processing...</source>
        <translation>Обработка...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2076"/>
        <source>Pre-processing for </source>
        <translation>Предварительная обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2091"/>
        <source>Installing </source>
        <translation>Установка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2098"/>
        <source>Post-processing for </source>
        <translation>Обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2288"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Произошла ошибка при загрузке или записи файла: %1. Пожалуйста, проверьте подключение к Интернету и свободное место на диске.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2373"/>
        <source>Downloading package info...</source>
        <translation>Загрузка информации о пакетах...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2727"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Команда dpkg-query завершилась с ошибкой. Пожалуйста, запустите &apos;dpkg-query -W&apos; в терминале и проверьте вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2971"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Команда dpkg-query завершилась с ошибкой. Пожалуйста, запустите &apos;dpkg-query -W&apos; в терминале и проверьте вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3105"/>
        <location filename="../src/mainwindow.cpp" line="3228"/>
        <location filename="../src/mainwindow.cpp" line="3262"/>
        <source>Package info</source>
        <translation>Информация о пакете</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3135"/>
        <location filename="../src/mainwindow.cpp" line="5187"/>
        <source>More &amp;info...</source>
        <translation>Подро&amp;бности...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3169"/>
        <source>Packages to be installed: </source>
        <translation>Пакеты для установки:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3420"/>
        <location filename="../src/mainwindow.cpp" line="3437"/>
        <location filename="../src/mainwindow.cpp" line="3494"/>
        <location filename="../src/mainwindow.cpp" line="3514"/>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="3655"/>
        <location filename="../src/mainwindow.cpp" line="3701"/>
        <location filename="../src/mainwindow.cpp" line="4500"/>
        <location filename="../src/mainwindow.cpp" line="5014"/>
        <location filename="../src/mainwindow.cpp" line="5112"/>
        <location filename="../src/mainwindow.cpp" line="5145"/>
        <location filename="../src/mainwindow.cpp" line="5246"/>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3420"/>
        <location filename="../src/mainwindow.cpp" line="3437"/>
        <location filename="../src/mainwindow.cpp" line="3494"/>
        <location filename="../src/mainwindow.cpp" line="3514"/>
        <location filename="../src/mainwindow.cpp" line="3628"/>
        <location filename="../src/mainwindow.cpp" line="3655"/>
        <location filename="../src/mainwindow.cpp" line="3701"/>
        <location filename="../src/mainwindow.cpp" line="3717"/>
        <location filename="../src/mainwindow.cpp" line="4500"/>
        <location filename="../src/mainwindow.cpp" line="5014"/>
        <location filename="../src/mainwindow.cpp" line="5112"/>
        <location filename="../src/mainwindow.cpp" line="5145"/>
        <location filename="../src/mainwindow.cpp" line="5246"/>
        <location filename="../src/mainwindow.cpp" line="5285"/>
        <source>Processing finished successfully.</source>
        <translation>Обработка успешно завершена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3432"/>
        <location filename="../src/mainwindow.cpp" line="3492"/>
        <location filename="../src/mainwindow.cpp" line="5140"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3442"/>
        <location filename="../src/mainwindow.cpp" line="3518"/>
        <location filename="../src/mainwindow.cpp" line="5018"/>
        <location filename="../src/mainwindow.cpp" line="5117"/>
        <location filename="../src/mainwindow.cpp" line="5152"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Обнаружена проблема при установке, пожалуйста, проверьте консольный вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3461"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3473"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3476"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3497"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3528"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3529"/>
        <source>Version: </source>
        <translation>Версия:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3531"/>
        <source>Package Installer for MX Linux</source>
        <translation>Установщик пакетов для MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3533"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Авторское право (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3534"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3540"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <location filename="../src/mainwindow.cpp" line="5239"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3645"/>
        <location filename="../src/mainwindow.cpp" line="3699"/>
        <location filename="../src/mainwindow.cpp" line="5241"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3646"/>
        <location filename="../src/mainwindow.cpp" line="5242"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3659"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>При деинсталляции возникла ошибка, пожалуйста, проверьте вывод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3679"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3680"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3704"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3717"/>
        <location filename="../src/mainwindow.cpp" line="5285"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3720"/>
        <location filename="../src/mainwindow.cpp" line="5288"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Возникла проблема при удалении приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3887"/>
        <location filename="../src/mainwindow.cpp" line="3938"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Не удалось загрузить список пакетов. Пожалуйста, проверьте ваши источники APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3986"/>
        <location filename="../src/mainwindow.cpp" line="4032"/>
        <source>Flatpak not installed</source>
        <translation>Флатпак не установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3987"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>В настоящий момент флатпак не установлен.
Начать его установку?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4032"/>
        <source>Flatpak was not installed</source>
        <translation>Флатпак не был установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4055"/>
        <location filename="../src/mainwindow.cpp" line="4429"/>
        <source>Needs re-login</source>
        <translation>Требуется повторить логин</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4056"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Возможно, вам потребуется выйти/войти в систему, чтобы увидеть в меню только что установленные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4299"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4335"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4359"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4416"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4421"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4425"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4505"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4709"/>
        <location filename="../src/mainwindow.cpp" line="4720"/>
        <location filename="../src/mainwindow.cpp" line="4832"/>
        <location filename="../src/mainwindow.cpp" line="4896"/>
        <source>Mark keep</source>
        <translation>Помечен &quot;оставлять&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4737"/>
        <source>Select/deselect all upgradable</source>
        <translation>Выбрать/снять выбор для всех имеющих обновления</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Выбрать/снять выбор для всех авто-удаляемых</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4834"/>
        <location filename="../src/mainwindow.cpp" line="4894"/>
        <source>Upgrade</source>
        <translation>Обновление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5046"/>
        <location filename="../src/mainwindow.cpp" line="5198"/>
        <source>Quit?</source>
        <translation>Выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5047"/>
        <location filename="../src/mainwindow.cpp" line="5199"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Процесс еще выполняется, выход может оставить систему в нестабильном состоянии.&lt;p&gt;&lt;b&gt;Вы уверены, что хотите выйти из MX Установщика пакетов?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4874"/>
        <source>Reinstall</source>
        <translation>Переустановить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4430"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4497"/>
        <location filename="../src/mainwindow.cpp" line="5109"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5251"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Обнаружена проблема во время последней операции, пожалуйста, проверьте вывод консоли.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5279"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Опасная операция.
Убедитесь, что вы внимательно проверили список удаляемых пакетов.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Управлять дистанционными флатпак</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>введите дистанционный адрес флатпака</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>Введите местоположение Flatpakref, чтобы установить приложение</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Добавить или удалить дистанционные флатпак (репозитории), или установить приложения, используя адрес или путь flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Удалить дистанционный</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Добавить дистанционный</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Установить приложение</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Не удаляемое</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Флатхаб является основным дистанционным для флатпака и не может быть удалён</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>Ошибка при добавлении дистанционного</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Не получилось добавить дистанционный - команда вернула ошибку. Перепроверьте адрес дистанционного и попробуйте заново</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>Дистанционный успешно добавлен</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Версия в репозитории</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>База данных Dpkg/apt заблокирована другой программой: %1
Закройте программу или подождите, пока она завершит обработку, и попробуйте снова.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Установщик пакетов — это средство управления пакетами в MX Linux
    - установка популярных программ из разных источников
    - установка программ из тестового хранилища MX
    - установка программ из хранилища Debian Backports
    - установка Флэтпаков</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Пропустить онлайн-проверку, если она ложно сообщает об отсутствии доступа к интернету.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="148"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="150"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="152"/>
        <source>Notes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="154"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
</TS>