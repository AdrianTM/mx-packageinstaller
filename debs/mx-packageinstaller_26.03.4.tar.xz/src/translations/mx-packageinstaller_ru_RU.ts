<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Пожалуйста, перезапустите приложение и введите пароль при появлении соответствующего запроса.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Полное имя</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Версия</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Ветка</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>MX Package Installer</source>
        <translation>MX Установщик пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Популярные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Управление популярными пакетами&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>поиск</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Установленные пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Включенные репозитории</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Удалите все пакеты, помеченные как &amp;quot;автоудаляемые&amp;quot;. Если вы хотите управлять ими, выберите «Автоудаляемые» в раскрывающемся списке.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Автоматическое удаление пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Обновить все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Установлено:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Всего пакетов:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Также устанавливать &quot;Рекомендуемые&quot; пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Доступно обновление:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Скрыть библиотеки и пакеты для разработчиков</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Обновить список</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Фильтровать пакеты в зависимости от их статуса.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <source>All packages</source>
        <translation>Все пакеты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4139"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4140"/>
        <source>Upgradable</source>
        <translation>Доступно обновление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4106"/>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <source>Not installed</source>
        <translation>Не установлено</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="4077"/>
        <location filename="../src/mainwindow.cpp" line="4142"/>
        <location filename="../src/mainwindow.cpp" line="4221"/>
        <location filename="../src/mainwindow.cpp" line="4312"/>
        <source>Autoremovable</source>
        <translation>Автоудаляемый</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Обновляемый пакет. Более новая версия доступна в выбранном репозитории.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Тестовый репозиторий</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Бэкпорты Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Флатпак</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="272"/>
        <location filename="../src/mainwindow.cpp" line="273"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Внешний репозиторий:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4088"/>
        <source>All apps</source>
        <translation>Все приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4094"/>
        <source>All runtimes</source>
        <translation>Все среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4100"/>
        <source>All available</source>
        <translation>Все доступные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4085"/>
        <source>Installed apps</source>
        <translation>Установленные приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4082"/>
        <source>Installed runtimes</source>
        <translation>Установленные среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4104"/>
        <source>All installed</source>
        <translation>Все установленные</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>Всего элементов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Установленные приложения:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Расширенный</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Общий размер установленного:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Удалить неиспользуемые среды выполнения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation>Только пакеты репозитория</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3648"/>
        <location filename="../src/mainwindow.cpp" line="3958"/>
        <source>Console Output</source>
        <translation>Вывод консоли</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Ответьте здесь или просто нажмите Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="1991"/>
        <location filename="../src/mainwindow.cpp" line="4126"/>
        <location filename="../src/mainwindow.cpp" line="4137"/>
        <location filename="../src/mainwindow.cpp" line="4251"/>
        <location filename="../src/mainwindow.cpp" line="4291"/>
        <location filename="../src/mainwindow.cpp" line="4311"/>
        <location filename="../src/mainwindow.cpp" line="4338"/>
        <source>Install</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="484"/>
        <source>Uninstalling packages...</source>
        <translation>Удаление пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="489"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Запуск предварительных операций перед удалением...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="509"/>
        <source>Running post-uninstall operations...</source>
        <translation>Запуск пост-деинсталляционных операций...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="526"/>
        <source>Refreshing sources...</source>
        <translation>Обновляются источники...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="539"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <location filename="../src/mainwindow.cpp" line="2181"/>
        <location filename="../src/mainwindow.cpp" line="2350"/>
        <location filename="../src/mainwindow.cpp" line="2427"/>
        <location filename="../src/mainwindow.cpp" line="2786"/>
        <location filename="../src/mainwindow.cpp" line="3030"/>
        <location filename="../src/mainwindow.cpp" line="3472"/>
        <location filename="../src/mainwindow.cpp" line="3489"/>
        <location filename="../src/mainwindow.cpp" line="3626"/>
        <location filename="../src/mainwindow.cpp" line="3640"/>
        <location filename="../src/mainwindow.cpp" line="3793"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <location filename="../src/mainwindow.cpp" line="4429"/>
        <location filename="../src/mainwindow.cpp" line="4542"/>
        <location filename="../src/mainwindow.cpp" line="4575"/>
        <location filename="../src/mainwindow.cpp" line="4672"/>
        <location filename="../src/mainwindow.cpp" line="4710"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="540"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Возникла проблема с обновлением источников. Возможно, некоторые источники не предоставили обновления. Для получения дополнительной информации проверьте:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="658"/>
        <location filename="../src/mainwindow.cpp" line="685"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Не удалось определить версию Debian. Выберите вашу версию:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Debian Version</source>
        <translation>Версия Debian</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1242"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>Please wait...</source>
        <translation>Пожалуйста, ждите...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1800"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Вы собираетесь использовать репозиторий MX Test, пакеты которого предоставляются только для тестирования. Возможно, они могут повредить вашу систему, поэтому рекомендуется создать резервную копию системы и устанавливать или обновлять только один пакет за раз. Пожалуйста, оставьте отзыв на Форуме, чтобы пакет мог быть оценен перед переносом в основной репозиторий.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1809"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Вы собираетесь использовать Debian Backports, который содержит пакеты, взятые из следующего выпуска Debian (называемого &apos;testing&apos;), настроенные и перекомпилированные для использования в Debian stable. Они не могут быть протестированы так же тщательно, как в стабильных версиях Debian и MX Linux, и предоставляются &quot;как есть&quot;, с риском несовместимости с другими компонентами в Debian stable. Используйте с осторожностью!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1817"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux включает этот репозиторий флатпаков только для удобства пользователей и не несёт ответственности за их функционирование. Подробнее о флатпаках в Вики.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1825"/>
        <location filename="../src/mainwindow.cpp" line="4700"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1829"/>
        <source>Do not show this message again</source>
        <translation>Не показывать это сообщение снова</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <source>Remove</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2004"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Следующие пакеты были выбраны. Нажмите &quot;Показать подробности&quot; для просмотра списка изменений.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2040"/>
        <location filename="../src/mainwindow.cpp" line="2182"/>
        <location filename="../src/mainwindow.cpp" line="2428"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Интернет недоступен, невозможно загрузить список пакетов</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2043"/>
        <source>Installing packages...</source>
        <translation>Установка пакетов...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2106"/>
        <source>Post-processing...</source>
        <translation>Обработка...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2138"/>
        <source>Pre-processing for </source>
        <translation>Предварительная обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2153"/>
        <source>Installing </source>
        <translation>Установка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2160"/>
        <source>Post-processing for </source>
        <translation>Обработка для</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2351"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Произошла ошибка при загрузке или записи файла: %1. Пожалуйста, проверьте подключение к Интернету и свободное место на диске.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2436"/>
        <source>Downloading package info...</source>
        <translation>Загрузка информации о пакетах...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2787"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>команда dpkg-query вернула ошибку. Пожалуйста, запустите &apos;dpkg-query -W&apos; в терминале и проверьте вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3031"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Команда dpkg-query вернула ошибку, запустите &apos;dpkg-query -W&apos; в терминале и проверьте вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3166"/>
        <location filename="../src/mainwindow.cpp" line="3285"/>
        <location filename="../src/mainwindow.cpp" line="3314"/>
        <source>Package info</source>
        <translation>Информация о пакете</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3194"/>
        <location filename="../src/mainwindow.cpp" line="4611"/>
        <source>More &amp;info...</source>
        <translation>Подро&amp;бности...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3228"/>
        <source>Packages to be installed: </source>
        <translation>Пакеты, которые будут установлены:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3455"/>
        <location filename="../src/mainwindow.cpp" line="3468"/>
        <location filename="../src/mainwindow.cpp" line="3486"/>
        <location filename="../src/mainwindow.cpp" line="3600"/>
        <location filename="../src/mainwindow.cpp" line="3623"/>
        <location filename="../src/mainwindow.cpp" line="4426"/>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <location filename="../src/mainwindow.cpp" line="4569"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Done</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3455"/>
        <location filename="../src/mainwindow.cpp" line="3468"/>
        <location filename="../src/mainwindow.cpp" line="3486"/>
        <location filename="../src/mainwindow.cpp" line="3600"/>
        <location filename="../src/mainwindow.cpp" line="3623"/>
        <location filename="../src/mainwindow.cpp" line="3637"/>
        <location filename="../src/mainwindow.cpp" line="4426"/>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <location filename="../src/mainwindow.cpp" line="4569"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <location filename="../src/mainwindow.cpp" line="4707"/>
        <source>Processing finished successfully.</source>
        <translation>Обработка успешно завершена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3464"/>
        <location filename="../src/mainwindow.cpp" line="4564"/>
        <source>Install complete.</source>
        <translation>Установка завершена.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3473"/>
        <location filename="../src/mainwindow.cpp" line="3490"/>
        <location filename="../src/mainwindow.cpp" line="4430"/>
        <location filename="../src/mainwindow.cpp" line="4543"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Обнаружена проблема при установке, пожалуйста, проверьте консольный вывод.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3500"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3501"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3503"/>
        <source>Package Installer for MX Linux</source>
        <translation>Установщик пакетов для MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3505"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3506"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3512"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3608"/>
        <location filename="../src/mainwindow.cpp" line="4661"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Удаление пакетов Flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3614"/>
        <location filename="../src/mainwindow.cpp" line="4663"/>
        <source>Uninstall complete.</source>
        <translation>Удаление завершено.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3615"/>
        <location filename="../src/mainwindow.cpp" line="4664"/>
        <source>Refreshing flatpaks...</source>
        <translation>Актуализация пакетов Flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3626"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>При деинсталляции возникла ошибка, пожалуйста, проверьте вывод</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3637"/>
        <location filename="../src/mainwindow.cpp" line="4707"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3640"/>
        <location filename="../src/mainwindow.cpp" line="4710"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Возникла проблема при удалении приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3794"/>
        <location filename="../src/mainwindow.cpp" line="3845"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Не удалось загрузить список пакетов. Пожалуйста, проверьте ваши источники APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3893"/>
        <location filename="../src/mainwindow.cpp" line="3939"/>
        <source>Flatpak not installed</source>
        <translation>Флатпак не установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3894"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>В настоящий момент флатпак не установлен.
Начать его установку?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3939"/>
        <source>Flatpak was not installed</source>
        <translation>Флатпак не был установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3962"/>
        <source>Needs re-login</source>
        <translation>Требуется повторить логин</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3963"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Вам может потребоваться выйти из системы и зайти снова, чтобы увидеть установленные элементы в меню.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4126"/>
        <location filename="../src/mainwindow.cpp" line="4137"/>
        <location filename="../src/mainwindow.cpp" line="4249"/>
        <location filename="../src/mainwindow.cpp" line="4313"/>
        <source>Mark keep</source>
        <translation>Отметка сохранена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4154"/>
        <source>Select/deselect all upgradable</source>
        <translation>Выбрать/отменить выбор всех обновляемых</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4155"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Выбрать/отменить выбор всех автоудаляемых</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4251"/>
        <location filename="../src/mainwindow.cpp" line="4311"/>
        <source>Upgrade</source>
        <translation>Обновление</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4458"/>
        <location filename="../src/mainwindow.cpp" line="4622"/>
        <source>Quit?</source>
        <translation>Выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4459"/>
        <location filename="../src/mainwindow.cpp" line="4623"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Процесс еще выполняется, выход может оставить систему в нестабильном состоянии.&lt;p&gt;&lt;b&gt;Вы уверены, что хотите выйти из MX Установщика пакетов?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4291"/>
        <source>Reinstall</source>
        <translation>Переустановить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4535"/>
        <source>Update complete.</source>
        <translation>Обновление завершено.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4673"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Обнаружена проблема во время последней операции, пожалуйста, проверьте вывод консоли.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4701"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Опасная операция.
Убедитесь, что вы внимательно проверили список удаляемых пакетов.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Управление внешними репозиториями Flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Для всех пользователей</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Для текущего пользователя</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>введите URL внешнего репозитория Флатпак</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>введите местоположение .flatpakref для установки приложения</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Добавить или удалить внешний репозиторий Флатпак, или установить приложения, используя адрес или путь к .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Удалить внешний репо</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Добавить внешний репо</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Установить приложение</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Не удаляемое</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub является основным внешним репозиторием Флатпак и не может быть удален</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Ошибка при добавлении внешнего репозитория</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Не получилось добавить внешний репозиторий - команда вернула ошибку. Перепроверьте адрес и попробуйте заново</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Внешний репозиторий успешно добавлен</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Версия в репозитории</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Установлено</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Категория</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Пакет</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>База данных Dpkg/apt заблокирована другой программой: %1
Закройте программу или подождите, пока она завершит обработку, и попробуйте снова.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Установщик пакетов — это средство управления пакетами в MX Linux
    - установка популярных программ из разных источников
    - установка программ из тестового репозитория MX
    - установка программ из репозитория Debian Backports
    - установка Флатпаков</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Пропустить онлайн проверку, если она ложно сообщает об отсутствии доступа в Интернет.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Вы должны запустить эту программу с правами администратора.</translation>
    </message>
</context>
</TS>