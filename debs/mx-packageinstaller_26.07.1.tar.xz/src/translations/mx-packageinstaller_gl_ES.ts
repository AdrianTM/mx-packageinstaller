<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl_ES">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="255"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="256"/>
        <source>This operation requires administrator privileges. Try the action again and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="177"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="179"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="181"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="183"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="185"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="349"/>
        <source>MX Package Installer</source>
        <translation>MX Instalador de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Xestionar paquetes populares&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <location filename="../src/mainwindow.ui" line="1580"/>
        <source>search</source>
        <translation>busca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>=Paquetes instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Repositorios habilitados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Elimina todos os paquetes marcados como &amp;quot;autoremovable&amp;quot;. Se queres xestionalos, selecciona Autoremovable no cadro de selección despregable.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Eliminar automaticamente paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Actualizar todos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Total de paquetes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Tamén instale os paquetes &quot;Recomendados&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Actualizables:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Agochar paquetes de bibliotecas e de desenvolvedor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <location filename="../src/mainwindow.ui" line="1590"/>
        <source>Refresh list</source>
        <translation>Recargar a lista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <location filename="../src/mainwindow.ui" line="1532"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrar paquetes polo estado.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4887"/>
        <source>All packages</source>
        <translation>Todos os paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4913"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4914"/>
        <source>Upgradable</source>
        <translation>Actualizables</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4880"/>
        <location filename="../src/mainwindow.cpp" line="4915"/>
        <source>Not installed</source>
        <translation>Non instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3613"/>
        <location filename="../src/mainwindow.cpp" line="4851"/>
        <location filename="../src/mainwindow.cpp" line="4916"/>
        <location filename="../src/mainwindow.cpp" line="4994"/>
        <location filename="../src/mainwindow.cpp" line="5085"/>
        <source>Autoremovable</source>
        <translation>Autoextraíble</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>=Paquete actualizable. Nova versión dispoñible no repositorio seleccionado.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>Repositorio de proba de MX</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Paquetes flatpak</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <source>For all users</source>
        <translation>Para todos os usuarios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Para o actual usuario</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>(Repositorio) remoto:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4862"/>
        <source>All apps</source>
        <translation>Aplicativos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4868"/>
        <source>All runtimes</source>
        <translation>Software &apos;runtime&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4874"/>
        <source>All available</source>
        <translation>Todo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4859"/>
        <source>Installed apps</source>
        <translation>Aplicativos instaladas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4856"/>
        <source>Installed runtimes</source>
        <translation>Software &apos;runtime&apos; instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4878"/>
        <source>All installed</source>
        <translation>Todos instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <location filename="../src/mainwindow.ui" line="1657"/>
        <source>Total items </source>
        <translation>Total de items</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Aplicativos instalados:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Total instalado:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Elimina os tempos de execución non utilizados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <source>Snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1535"/>
        <location filename="../src/mainwindow.ui" line="1539"/>
        <location filename="../src/mainwindow.cpp" line="4443"/>
        <location filename="../src/mainwindow.cpp" line="4667"/>
        <source>Installed snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1544"/>
        <location filename="../src/mainwindow.cpp" line="4358"/>
        <location filename="../src/mainwindow.cpp" line="4446"/>
        <location filename="../src/mainwindow.cpp" line="4448"/>
        <location filename="../src/mainwindow.cpp" line="4737"/>
        <source>Search store</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1577"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type a term and press Enter to search the snap store.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1609"/>
        <source>Snap support is not set up on this system. Click the button to install snapd and enable the Snap service.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1619"/>
        <source>Set up Snap support</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1671"/>
        <source>Installed snaps:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1698"/>
        <source>Update All</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1721"/>
        <location filename="../src/mainwindow.cpp" line="3857"/>
        <location filename="../src/mainwindow.cpp" line="4223"/>
        <source>Console Output</source>
        <translation>Procesamento en consola</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1737"/>
        <source>Respond here, or just press Enter</source>
        <translation>Responder aquí ou premer enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1796"/>
        <location filename="../src/mainwindow.cpp" line="1971"/>
        <location filename="../src/mainwindow.cpp" line="4652"/>
        <location filename="../src/mainwindow.cpp" line="4900"/>
        <location filename="../src/mainwindow.cpp" line="4911"/>
        <location filename="../src/mainwindow.cpp" line="5024"/>
        <location filename="../src/mainwindow.cpp" line="5064"/>
        <location filename="../src/mainwindow.cpp" line="5084"/>
        <location filename="../src/mainwindow.cpp" line="5125"/>
        <source>Install</source>
        <translation>Instalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1802"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1821"/>
        <source>Quit application</source>
        <translation>Saír do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1824"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1830"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1862"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1865"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1871"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1909"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1912"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1918"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1934"/>
        <source>Uninstall</source>
        <translation>Desinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1940"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="559"/>
        <source>Uninstalling packages...</source>
        <translation>Desinstalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="564"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Realizando operacións previas á desinstalación...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="584"/>
        <source>Running post-uninstall operations...</source>
        <translation>Executando operacions despois de desinstalar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="601"/>
        <source>Refreshing sources...</source>
        <translation>Actualizando as orixes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <location filename="../src/mainwindow.cpp" line="2023"/>
        <location filename="../src/mainwindow.cpp" line="2168"/>
        <location filename="../src/mainwindow.cpp" line="2357"/>
        <location filename="../src/mainwindow.cpp" line="2435"/>
        <location filename="../src/mainwindow.cpp" line="2813"/>
        <location filename="../src/mainwindow.cpp" line="3051"/>
        <location filename="../src/mainwindow.cpp" line="3545"/>
        <location filename="../src/mainwindow.cpp" line="3623"/>
        <location filename="../src/mainwindow.cpp" line="3784"/>
        <location filename="../src/mainwindow.cpp" line="3847"/>
        <location filename="../src/mainwindow.cpp" line="4018"/>
        <location filename="../src/mainwindow.cpp" line="4069"/>
        <location filename="../src/mainwindow.cpp" line="4242"/>
        <location filename="../src/mainwindow.cpp" line="5216"/>
        <location filename="../src/mainwindow.cpp" line="5317"/>
        <location filename="../src/mainwindow.cpp" line="5352"/>
        <location filename="../src/mainwindow.cpp" line="5451"/>
        <location filename="../src/mainwindow.cpp" line="5491"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="615"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Houbo un problema ao actualizar as orixes. Algunhas orixes poden non ter fornecido actualizacións. Para máis información, ver:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="727"/>
        <location filename="../src/mainwindow.cpp" line="754"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="760"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1225"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1231"/>
        <source>Please wait...</source>
        <translation>Agarda...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1773"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>O repositório MX Test, cuxos paquetes son dispoñibilizados só para efecto de probar, está para ser usado. Os paquetes deste repositorio poden damnificar o sistema, polo que se suxire que sexa feita unha copia de seguranza do mesmo e que sexa instalado ou actualizado só un paquete de cada vez. Agradécese que os resultados sexan comunicados no foro, para que haxa unha avalición dos paquetes antes de seren movidos para o repositorio principal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1782"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Será usado o repositorio &apos;Debian Backports&apos;, que contén paquetes retirados da versión (chamada &apos;testing&apos;) de Debian, adaptados e recompilados para uso na actual versión estable de Debian, sendo por isto designados paquetes retro-portados. Estes paquetes non foron tan extensivamente probados como os das versións estables de Debian e de MX; son dispoñibilizados &apos;como están&apos;, co risco de incompatibilidades con outros compoñentes de Debian &apos;estable&apos;. Usar con coidado!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1790"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>O MX inclúe este repositorio de paquetes flatpak só para conveniencia dos usuarios, non sendo responsable polo funcionamento dos propios paquetes flatpak. Para máis información, consultar &apos;flatpaks&apos; na Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1798"/>
        <location filename="../src/mainwindow.cpp" line="5481"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1802"/>
        <source>Do not show this message again</source>
        <translation>Non amosar esta mensaxe de novo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1968"/>
        <source>Remove</source>
        <translation>Eliminar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1984"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Seleccionáronse os seguintes paquetes. Preme en Amosar detalles para ver a lista de cambios.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2024"/>
        <location filename="../src/mainwindow.cpp" line="2169"/>
        <location filename="../src/mainwindow.cpp" line="2436"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Sen conexión a Internet; non é posible descargar a lista de paquetes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2027"/>
        <source>Installing packages...</source>
        <translation>Instalando paquetes...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <source>Post-processing...</source>
        <translation>Posprocesando...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2122"/>
        <source>Pre-processing for </source>
        <translation>Prepocesando para</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2137"/>
        <source>Installing </source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2147"/>
        <source>Post-processing for </source>
        <translation>Posprocesando para</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2358"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Produciuse un erro ao escribir o ficheiro: %1. Comproba se tes espazo libre suficiente na túa unidade</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2444"/>
        <source>Downloading package info...</source>
        <translation>Descargando información do paquete...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2814"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando dpkg devolveu un erro, por favor executa  &apos;dpkg-query -W&apos;  no terminal e verifica a saída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3052"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>O comando dpkg devolveu un erro. Executa  &apos;dpkg-query -W&apos;  no terminal e verifica a saída.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3186"/>
        <location filename="../src/mainwindow.cpp" line="3302"/>
        <location filename="../src/mainwindow.cpp" line="3350"/>
        <source>Package info</source>
        <translation>Información do paquete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3218"/>
        <location filename="../src/mainwindow.cpp" line="5388"/>
        <source>More &amp;info...</source>
        <translation>Máis &amp;información...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3243"/>
        <source>Packages to be installed: </source>
        <translation>Paquetes instalándose:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3541"/>
        <location filename="../src/mainwindow.cpp" line="3598"/>
        <location filename="../src/mainwindow.cpp" line="3620"/>
        <location filename="../src/mainwindow.cpp" line="3780"/>
        <location filename="../src/mainwindow.cpp" line="3826"/>
        <location filename="../src/mainwindow.cpp" line="4688"/>
        <location filename="../src/mainwindow.cpp" line="5213"/>
        <location filename="../src/mainwindow.cpp" line="5313"/>
        <location filename="../src/mainwindow.cpp" line="5346"/>
        <location filename="../src/mainwindow.cpp" line="5447"/>
        <source>Done</source>
        <translation>Feito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3541"/>
        <location filename="../src/mainwindow.cpp" line="3598"/>
        <location filename="../src/mainwindow.cpp" line="3620"/>
        <location filename="../src/mainwindow.cpp" line="3780"/>
        <location filename="../src/mainwindow.cpp" line="3826"/>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <location filename="../src/mainwindow.cpp" line="4688"/>
        <location filename="../src/mainwindow.cpp" line="5213"/>
        <location filename="../src/mainwindow.cpp" line="5313"/>
        <location filename="../src/mainwindow.cpp" line="5346"/>
        <location filename="../src/mainwindow.cpp" line="5447"/>
        <location filename="../src/mainwindow.cpp" line="5488"/>
        <source>Processing finished successfully.</source>
        <translation>Procesamento rematado con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3536"/>
        <location filename="../src/mainwindow.cpp" line="3596"/>
        <location filename="../src/mainwindow.cpp" line="5341"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3546"/>
        <location filename="../src/mainwindow.cpp" line="3624"/>
        <location filename="../src/mainwindow.cpp" line="5217"/>
        <location filename="../src/mainwindow.cpp" line="5318"/>
        <location filename="../src/mainwindow.cpp" line="5353"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Detectado problema ao instalar; verificar información na consola. </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3565"/>
        <source>Install snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3566"/>
        <source>OK to install the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3577"/>
        <source>Installing packages: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3580"/>
        <source>Installing package: %1...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3601"/>
        <source>Problem detected while installing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3636"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3637"/>
        <source>Version: </source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3639"/>
        <source>Package Installer for MX Linux</source>
        <translation>Xestor de paquetes de MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3641"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3642"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3648"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3761"/>
        <location filename="../src/mainwindow.cpp" line="5440"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3770"/>
        <location filename="../src/mainwindow.cpp" line="3824"/>
        <location filename="../src/mainwindow.cpp" line="5442"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3771"/>
        <location filename="../src/mainwindow.cpp" line="5443"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3784"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Foi atopado un problema ao desinstalar. Verificar os resultados.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3804"/>
        <source>Remove snaps</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3805"/>
        <source>OK to remove the following snap packages?

%1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3829"/>
        <source>We encountered a problem removing a snap. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3844"/>
        <location filename="../src/mainwindow.cpp" line="5488"/>
        <source>Success</source>
        <translation>Con éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3847"/>
        <location filename="../src/mainwindow.cpp" line="5491"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Houbo un problema ao desinstalar o programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4019"/>
        <location filename="../src/mainwindow.cpp" line="4070"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Non se puido descargar a lista de paquetes. Por favor, comprobe as súas fontes de APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4150"/>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Flatpak not installed</source>
        <translation>Paquete flatpak non instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4151"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>O paquete flatpak non está instalado.
Continuar e instalar o paquete?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4204"/>
        <source>Flatpak was not installed</source>
        <translation>O paquete flatpak non estaba instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4227"/>
        <location filename="../src/mainwindow.cpp" line="4616"/>
        <source>Needs re-login</source>
        <translation>É necesario volver a iniciar sesió</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4228"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Poderá ser necesario saír e volver a iniciar sesión para ue os items queden visibles no menú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4471"/>
        <source>No results</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4471"/>
        <source>No snaps found matching &quot;%1&quot;.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4514"/>
        <source>snapd was not installed. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4538"/>
        <source>Installing the base &quot;core&quot; snap...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <source>No output was captured. Run &apos;sudo snap install core&apos; in a terminal to see the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4608"/>
        <source>snapd was installed but its service could not be started. You may need to reboot or log out and back in, then reopen the Snap tab. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4612"/>
        <source>Snap support was enabled, but the base &quot;core&quot; snap could not be installed, so most snaps will not work yet. Click &quot;Show Details&quot; for the underlying error.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4693"/>
        <source>Problem detected while updating snaps. Click &quot;Show Details&quot; for more information.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4900"/>
        <location filename="../src/mainwindow.cpp" line="4911"/>
        <location filename="../src/mainwindow.cpp" line="5022"/>
        <location filename="../src/mainwindow.cpp" line="5086"/>
        <source>Mark keep</source>
        <translation>Marca para conservar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4927"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4928"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5024"/>
        <location filename="../src/mainwindow.cpp" line="5084"/>
        <source>Upgrade</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5247"/>
        <location filename="../src/mainwindow.cpp" line="5399"/>
        <source>Quit?</source>
        <translation>Saír?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5248"/>
        <location filename="../src/mainwindow.cpp" line="5400"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>O proceso aínda está en execución. Saír pode deixar o sistema nun estado instable.&lt;p&gt;&lt;b&gt;Saír realmente do MX instalador de paquetes?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5064"/>
        <source>Reinstall</source>
        <translation>Reinstalar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4617"/>
        <source>Log out and back in to see installed items in the menu and use snap commands from /snap/bin. These changes do not apply to your current session.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4685"/>
        <location filename="../src/mainwindow.cpp" line="5310"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5452"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Detectouse un problema durante a última operación. Inspeccione a saída da consola.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="5482"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Operación potencialmente perigosa.
Asegúrate de comprobar coidadosamente a lista de paquetes a eliminar.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Xestionar repositorios remotos flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Para todos os usuarios</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Para o actual usuario</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>introducir o URL do repositorio remoto flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>para instalar un aplicativo, introducir a localización do respectivo ficheiro .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Engadir ou eliminar repositorios remotos flatpak ou instalr aplicativos usando o URL ou o camiño para o respectivo ficheiro .flatpakref</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Eliminar repositorio remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Engadir repositorio remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Instalar aplicativo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Non se pode eliminar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>O Flathub é o principal repositorio remoto flatpak e non será eliminado</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>Erro ao engadir o repositorio remoto</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Non é posible engadir o repositorio remoto - o comando resultou un erro. Verificar o enderezo do repositorio remoto e volver a intentar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Con éxito</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>Repositorio remoto engadido con éxito</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Versión de repositorio</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Instalado</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Descrición</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoría</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Información</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descrición</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="59"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="60"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>A base de datos de Dpkg/apt está bloqueada por outro programa: %1
Peche o programa, ou agarde ata que remate o procesamento e ténteo de novo.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>O instalador de paquetes MX é unha ferramenta utilizada para xestionar paquetes en MX Linux
    - instala programas populares de diferentes fontes
    - instala programas do repositorio de probas de MX
    - instala programas do repositorio de Debian Backports
    - instala flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Ignora a comprobación en liña se informa erroneamente da falta de acceso á internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O usuario parece ser root; para usar este programa, pechar a sesión e iniciar sesión como usuario normal.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Debes executar este programa con acceso de administrador.</translation>
    </message>
</context>
<context>
    <name>SnapModel</name>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="146"/>
        <source>Package</source>
        <translation>Paquete</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="148"/>
        <source>Version</source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="150"/>
        <source>Publisher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="152"/>
        <source>Notes</source>
        <translation>Notas</translation>
    </message>
    <message>
        <location filename="../src/models/snapmodel.cpp" line="154"/>
        <source>Description</source>
        <translation>Descrición</translation>
    </message>
</context>
</TS>