<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Rootrechte erforderlich</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Dieser Vorgang erfordert Rootrechte. Bitte starten Sie das Programm erneut und geben auf Anforderung Ihr Paßwort ein.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Vollständiger Name</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Teilgebiet</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>MX Package Installer</source>
        <translation>MX-Paketinstallation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Beliebte Anwendungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Beliebte Pakete verwalten&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>Suche </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Installierte Pakete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Aktivierte Paketquellen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>Alle Pakete entfernen, die als &amp;quot;automatisch entfernbar&amp;quot; markiert sind. Wählen Sie &quot;Automatisch entfernbar&quot; aus der Dropdown-Auswahlbox, wenn Sie die Pakete verwalten möchten.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Pakete automatisch entfernen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Alle aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Installiert:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Pakete gesamt:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Auch »empfohlene« Pakete installieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Aktualisierbar:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Bibliotheken und Entwicklerpakete verstecken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Liste aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pakete anhand ihres Status filtern.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4120"/>
        <source>All packages</source>
        <translation>Alle Pakete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4146"/>
        <source>Installed</source>
        <translation>Installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4147"/>
        <source>Upgradable</source>
        <translation>Aktualisierbar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <source>Not installed</source>
        <translation>Nicht installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3486"/>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <location filename="../src/mainwindow.cpp" line="4149"/>
        <location filename="../src/mainwindow.cpp" line="4228"/>
        <location filename="../src/mainwindow.cpp" line="4319"/>
        <source>Autoremovable</source>
        <translation>Automatisch entfernbar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Aktualisierbares Paket. Eine neuere Version ist bei der ausgewählten Paketquelle verfügbar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX-Test-Paketquellen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="279"/>
        <source>For all users</source>
        <translation>Für alle Benutzer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Für aktuellen Benutzer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Flatpak-Paketquellen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4095"/>
        <source>All apps</source>
        <translation>Alle Anwendungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>All runtimes</source>
        <translation>Alle Laufzeitbibliotheken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4107"/>
        <source>All available</source>
        <translation>Alle verfügbaren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4092"/>
        <source>Installed apps</source>
        <translation>Installierte Anwendungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4089"/>
        <source>Installed runtimes</source>
        <translation>Installierte Laufzeitbibliotheken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4111"/>
        <source>All installed</source>
        <translation>Es wurde alles installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>Gesamtanzahl</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Installierte Anwendungen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Fortgeschritten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Gesamte Installationsgröße:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Nicht benötigte Laufzeitbibliotheken entfernen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Alles auswählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation>Nur Repo Pakete</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3655"/>
        <location filename="../src/mainwindow.cpp" line="3965"/>
        <source>Console Output</source>
        <translation>Konsolenausgabe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Eingabetaste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Hier antworten oder einfach die Eingabetaste betätigen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="1997"/>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <location filename="../src/mainwindow.cpp" line="4345"/>
        <source>Install</source>
        <translation>Installieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Deinstallieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Uninstalling packages...</source>
        <translation>Deinstalliere Pakete...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="495"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Deinstallation wird vorbereitet...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>Running post-uninstall operations...</source>
        <translation>Vordefinierte Aktionen nach dem Deinstallieren werden ausgeführt ....</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <source>Refreshing sources...</source>
        <translation>Quellen werden neu eingelesen....</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <location filename="../src/mainwindow.cpp" line="2045"/>
        <location filename="../src/mainwindow.cpp" line="2187"/>
        <location filename="../src/mainwindow.cpp" line="2356"/>
        <location filename="../src/mainwindow.cpp" line="2433"/>
        <location filename="../src/mainwindow.cpp" line="2792"/>
        <location filename="../src/mainwindow.cpp" line="3036"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="3496"/>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="3800"/>
        <location filename="../src/mainwindow.cpp" line="3851"/>
        <location filename="../src/mainwindow.cpp" line="4436"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4582"/>
        <location filename="../src/mainwindow.cpp" line="4679"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Ein Problem ist beim Aktualisieren der Quellen aufgetreten. Einige Quellen könnten nicht aktualisiert worden sein. Für mehr Informationen siehe:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="664"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Debian Version konnte nicht ermittelt werden. Bitte Version auswählen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Debian Version</source>
        <translation>Debian Version</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>Cancel</source>
        <translation>Abbruch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <source>Please wait...</source>
        <translation>Bitte warten...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Sie sind im Begriff, die MX-Testpaketquelle zu nutzen, dessen Pakete nur zu Testzwecken verfügbar sind. Es ist möglich, daß diese Pakete das System unbrauchbar machen; deshalb wird empfohlen, eine Sicherung des Systems anzulegen und immer nur einzelne Pakete zu installieren oder zu aktualisieren. Bitte geben Sie auch Rückmeldungen im Forum ab, damit das jeweilige Paket evaluiert werden kann, bevor es in die stabile Version übernommen wird.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1815"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Sie sind dabei, Debian Backports zu benutzen, welches Pakete aus der nächsten Debian Freigabe (&quot;testing&quot;) enthält, die zur Nutzung in Debian Stable angepasst und neu kompiliert wurden. Diese Pakete konnten nicht so intensiv wie in der stabilen Freigabe von Debian und MX Linux getestet werden und werden ohne Garantie und mit dem Risiko der Inkompatibilität zu Komponenten aus Debian Stable zur Verfügung gestellt. Mit Vorsicht verwenden! </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux enthält diese Paketquelle von Flatpaks nur aus Gründen der Benutzerfreundlichkeit und ist nicht verantwortlich für die Funktionalität der einzelnen Flatpaks. Nähere Infos dazu stehen im Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1831"/>
        <location filename="../src/mainwindow.cpp" line="4707"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1835"/>
        <source>Do not show this message again</source>
        <translation>Diese Meldung nicht mehr anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1994"/>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2010"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Die folgenden Pakete wurden ausgewählt. Zur Anzeige einer Übersicht aller Änderungen klicken Sie bitte auf »Details anzeigen«.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2046"/>
        <location filename="../src/mainwindow.cpp" line="2188"/>
        <location filename="../src/mainwindow.cpp" line="2434"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet ist nicht verfügbar. Die  Paketeliste kann nicht heruntergeladen werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2049"/>
        <source>Installing packages...</source>
        <translation>Installiere Pakete...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2112"/>
        <source>Post-processing...</source>
        <translation>Nachbearbeitung...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <source>Pre-processing for </source>
        <translation>Vorverarbeitung für</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2159"/>
        <source>Installing </source>
        <translation>Installiere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2166"/>
        <source>Post-processing for </source>
        <translation>Nachbearbeitung für</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2357"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Beim Herunterladen oder Speichern der Datei %1 ist ein Fehler aufgetreten. Bitte prüfen Sie Ihre Internetverbindung und den freien Speicherplatz auf dem Speichermedium sowie ihre Zugriffsberechtigungen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2442"/>
        <source>Downloading package info...</source>
        <translation>Lade Paketinformationen herunter...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Der Befehl &quot;dpkg-query&quot; hat einen Fehler gemeldet. Führen Sie bitte &quot;dpkg-query -W&quot; im Terminal aus und prüfen Sie das Ergebnis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3037"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>Der Befehl &quot;dpkg-query&quot; hat einen Fehler gemeldet. Führen Sie bitte &quot;dpkg-query -W&quot; im Terminal aus und prüfen Sie das Ergebnis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3172"/>
        <location filename="../src/mainwindow.cpp" line="3291"/>
        <location filename="../src/mainwindow.cpp" line="3321"/>
        <source>Package info</source>
        <translation>Paketinformationen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3200"/>
        <location filename="../src/mainwindow.cpp" line="4618"/>
        <source>More &amp;info...</source>
        <translation>Weitere &amp;Informationen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3234"/>
        <source>Packages to be installed: </source>
        <translation>Zu installierende Pakete:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <source>Done</source>
        <translation>Erledigt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Processing finished successfully.</source>
        <translation>Die Installation war erfolgreich.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3471"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <source>Install complete.</source>
        <translation>Installation abgeschlossen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3480"/>
        <location filename="../src/mainwindow.cpp" line="3497"/>
        <location filename="../src/mainwindow.cpp" line="4437"/>
        <location filename="../src/mainwindow.cpp" line="4550"/>
        <location filename="../src/mainwindow.cpp" line="4583"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Bei der Installation trat ein Problem auf; siehe Konsolenausgabe </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3507"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3508"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3510"/>
        <source>Package Installer for MX Linux</source>
        <translation>Paket-Installation für MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3512"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3513"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3519"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3615"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Flatpaks werden deinstalliert...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3621"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Uninstall complete.</source>
        <translation>Deinstallation abgeschlossen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3622"/>
        <location filename="../src/mainwindow.cpp" line="4671"/>
        <source>Refreshing flatpaks...</source>
        <translation>Flatpaks werden aktualisiert...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Es gab ein Problem beim Deinstallieren. Bitte die Ausgabe überprüfen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Beim Deinstallieren des Programms trat ein Problem auf</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3801"/>
        <location filename="../src/mainwindow.cpp" line="3852"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Die Liste der Pakete konnte nicht heruntergeladen werden. Bitte überprüfen Sie Ihre APT-Quellen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3900"/>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak nicht installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3901"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak ist noch nicht installiert.
Mit OK die Installation einleiten?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak wurde nicht installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3969"/>
        <source>Needs re-login</source>
        <translation>Erneutes Anmelden erforderlich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3970"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Erst nach dem Ab-/Neuanmelden werden installierte Anwendungen im Menü sichtbar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4320"/>
        <source>Mark keep</source>
        <translation>Zum Behalten markieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <source>Select/deselect all upgradable</source>
        <translation>Alle Pakete mit höheren Versionen auswählen/abwählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4162"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Alle Pakete mit automatischer Löschung auswählen/abwählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <source>Upgrade</source>
        <translation>Aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <location filename="../src/mainwindow.cpp" line="4629"/>
        <source>Quit?</source>
        <translation>Beenden? </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Der Prozess läuft noch, das Beenden könnte das System in einen instabilen Zustand versetzen.&lt;p&gt;&lt;b&gt;Sind Sie sicher, daß Sie das MX-Paketinstallationsprogrammn beenden möchten?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Reinstall</source>
        <translation>Erneut installieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4542"/>
        <source>Update complete.</source>
        <translation>Update abgeschlossen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4680"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Während des letzten Vorgangs wurde ein Problem festgestellt. Bitte überprüfen Sie die Konsolenausgabe.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4708"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Der Vorgang ist potentiell riskant
Bitte überprüfen Sie sorgfältig die Liste der zum Entfernen vorgesehenen Pakete.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Flatpak-Paketquellen verwalten</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Für alle Benutzer</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Für aktuellen Benutzer</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>Flatpak-Paketquellen-URL eingeben</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>Flatpakref Pfad/URL zur Installation eingeben</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Flatpak-Paketquellen hinzufügen oder entfernen, oder Installation von Flatpak-Apps mit Flatpakref (Pfad/URL)</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Flatpak-Paketquelle entfernen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Flatpak-Paketquelle hinzufügen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Anwendung installieren</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Nicht entfernbar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub ist die Flatpak-Haupt-Paketquelle und kann nicht entfernt werden</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Fehler beim Hinzufügen der Paketquelle</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Konnte die Paketquelle nicht hinzufügen - der Befehl endete mit einem Fehler. Bitte die Paketquellen-URL überprüfen und nochmal versuchen.</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Flatpak-Paketquelle erfolgreich hinzugefügt</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Repository-Version</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Installiert</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategorie</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Informationen</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Änderungsprotokoll konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Die dpkg/apt-Datenbank ist durch ein anderes Programm gesperrt: %1
Bitte das Programm schließen oder warten, bis es fertig ist und es dann erneut versuchen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX-Paketinstallation ist eine Anwendung zur Verwaltung von Paketen in MX-Linux
    - installiert beliebte Programme aus verschiedenen Quellen
    - installiert Programme aus der MX-Test-Paketquelle
    - installiert Programme aus der Debian-Backports-Paketquelley
    - installiert Flatpak-Dateien</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Den Online-Check überspringen, wenn fälschlicherweise gemeldet wird, dass kein Internetzugang vorhanden ist.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sie sind als Administrator am System angemeldet. Bitte melden Sie sich ab und dann als normaler Benutzer wieder an, um dieses Programm zu verwenden.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Diese Anwendung muss mit Administratorrechten ausgeführt werden.</translation>
    </message>
</context>
</TS>