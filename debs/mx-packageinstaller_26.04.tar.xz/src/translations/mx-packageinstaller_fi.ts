<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fi">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Pääkäyttäjän oikeudet vaaditaan</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Toiminto vaatii pääkäyttäjän oikeudet. Käynnistä sovellus uudelleen ja anna salasanasi pyydettäessä.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation>Koko nimi</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Versio</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation>Haara</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>MX Package Installer</source>
        <translation>MX Sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Suositut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Suosittuja paketteja&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>hae</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= tietokoneeseen asennetut paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Arkistot käytössä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Poistaa kaikki paketit, jotka on merkitty &quot;automaattisesti poistettaviksi&quot;. Jos haluat tehdä muutoksia, valitse Autom. poistettavat pudotusvalikosta.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Autom. poistettavat paketit </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Päivitä kaikki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Asennettu:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Paketteja:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Asenna myös &quot;suositellut&quot; paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Päivitettävissä:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Piilota kirjasto ja kehittäjäpaketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Päivitä luettelo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Suodata paketit niiden tilan suhteen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4120"/>
        <source>All packages</source>
        <translation>Kaikki paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4146"/>
        <source>Installed</source>
        <translation>Asennettu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4147"/>
        <source>Upgradable</source>
        <translation>Päivitettävissä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <source>Not installed</source>
        <translation>Ei asennettu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3486"/>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <location filename="../src/mainwindow.cpp" line="4149"/>
        <location filename="../src/mainwindow.cpp" line="4228"/>
        <location filename="../src/mainwindow.cpp" line="4319"/>
        <source>Autoremovable</source>
        <translation>Autom. poistettavat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= päivitettävissä oleva paketti. Uudempi versio on saatavilla valitusta lähteestä.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Test Repo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpakit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="279"/>
        <source>For all users</source>
        <translation>Kaikille käyttäjille</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Vain minulle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Ulkopuolinen (arkisto):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4095"/>
        <source>All apps</source>
        <translation>Kaikki sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>All runtimes</source>
        <translation>Kaikki suoritusympäristöt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4107"/>
        <source>All available</source>
        <translation>Kaikki saatavilla olevat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4092"/>
        <source>Installed apps</source>
        <translation>Asennetut sovellukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4089"/>
        <source>Installed runtimes</source>
        <translation>Asennetut suoritusympäristöt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4111"/>
        <source>All installed</source>
        <translation>Kaikki asennetut</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>Kohteita:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Asennetut sovellukset:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Lisäasetukset</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Koko asennettuna:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Poista käyttämättömät suoritusajat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation>Vain arkiston paketit</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3655"/>
        <location filename="../src/mainwindow.cpp" line="3965"/>
        <source>Console Output</source>
        <translation>Konsoli</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Vastaa tähän, tai paina vain Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="1997"/>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <location filename="../src/mainwindow.cpp" line="4345"/>
        <source>Install</source>
        <translation>Asenna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation>Sulje sovellus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Tietoja sovelluksesta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>Tietoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Näytä ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Uninstalling packages...</source>
        <translation>Poistetaan paketteja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="495"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Suoritetaan asennusta edeltäviä poistoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>Running post-uninstall operations...</source>
        <translation>Ajetaan jälkiasennuksen toimia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <source>Refreshing sources...</source>
        <translation>Päivitetään lähdeluetteloita...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <location filename="../src/mainwindow.cpp" line="2045"/>
        <location filename="../src/mainwindow.cpp" line="2187"/>
        <location filename="../src/mainwindow.cpp" line="2356"/>
        <location filename="../src/mainwindow.cpp" line="2433"/>
        <location filename="../src/mainwindow.cpp" line="2792"/>
        <location filename="../src/mainwindow.cpp" line="3036"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="3496"/>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="3800"/>
        <location filename="../src/mainwindow.cpp" line="3851"/>
        <location filename="../src/mainwindow.cpp" line="4436"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4582"/>
        <location filename="../src/mainwindow.cpp" line="4679"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Lähteitä päivitettäessä kohdattiin ongelma. Jotkut lähteet eivät ehkä tuottaneet näytille päivityksiä. Lisätietoja varten:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="664"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Ei voitu määrittää Debian-versiota. Valitse versio:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Debian Version</source>
        <translation>Debian-versio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <source>Please wait...</source>
        <translation>Odota, ole hyvä...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Olet aikeissa käyttää MX Testiarkistoa, jonka paketit on tarkoitettu vain testikäyttöön. Ne saattavat rikkoa järjestelmäsi, joten on suositeltavaa että varmuuskopioit järjestelmäsi sekä asennat tai päivität vain yhden paketin kerrallaan. Anna palautetta paketista ja sen toimivuudesta foorumilla, jotta paketti voidaan arvioida ennen sen siirtämistä varsinaiseen jakeluun.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1815"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Olet aikomuksessa käyttää Debian:in Takaporttiohjelmistolähdettä, joka sisältää paketteja, jotka ovat otetut tulevasta Debian:in julkaisusta (nimeltään &apos;testing&apos;), säädettynä ja uudelleenkoottuna käytettäväksi sitten Debian:in vakaassa julkaisussa myöhemmin. Niitä ei ole voitu testata yhtä läpikotaisesti kuten Debian:in ja antiX:in vakaiden julkaisujen suhteen ja ne on annettu tarjolle sellaisena kuin ne sillä hetkellä ovat, sisältäen yhteensopivuusriskejä Debian:in vakaaseenjulkaisuun verrattuna. Käytä siis varauksella! </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux sisällyttää flatpak ohjelmat vain käyttäjän mukavuutta tavoitellen, eikä ole itse vastuussa flatpakien toimivuudesta. Lisätietoja, lue Wiki-sivujen osiosta flatpak.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1831"/>
        <location filename="../src/mainwindow.cpp" line="4707"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1835"/>
        <source>Do not show this message again</source>
        <translation>Älä näytä tätä viestiä uudelleen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1994"/>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2010"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Seuraavat paketit valittiin. Painike &quot;Näytä tiedot&quot; näyttää luettelon muutoksista.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2046"/>
        <location filename="../src/mainwindow.cpp" line="2188"/>
        <location filename="../src/mainwindow.cpp" line="2434"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet ei ole käytettävissä, pakettilistauksen lataaminen ei onnistu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2049"/>
        <source>Installing packages...</source>
        <translation>Asennetaan paketteja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2112"/>
        <source>Post-processing...</source>
        <translation>Esikäsittely käynnissä...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <source>Pre-processing for </source>
        <translation>Esikäsittely kohteelle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2159"/>
        <source>Installing </source>
        <translation>Asennetaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2166"/>
        <source>Post-processing for </source>
        <translation>Jälkikäsittely kohteelle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2357"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Virhe ladattaessa tai kirjoitettaessa: %1. Tarkista Internet-yhteys ja aseman vapaa tila</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2442"/>
        <source>Downloading package info...</source>
        <translation>Paketin tietoja ladataan...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>dpkg-komento palautti virheen, suorita &quot;dpkg-query -W&quot; terminaalissa ja tarkista tulos.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3037"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>dpkg-kysely palautti virheen, suorita terminaalissa &quot;dpkg-query -W&quot; ja tarkista tulos.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3172"/>
        <location filename="../src/mainwindow.cpp" line="3291"/>
        <location filename="../src/mainwindow.cpp" line="3321"/>
        <source>Package info</source>
        <translation>Paketin tiedot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3200"/>
        <location filename="../src/mainwindow.cpp" line="4618"/>
        <source>More &amp;info...</source>
        <translation>&amp;Lisätietoja...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3234"/>
        <source>Packages to be installed: </source>
        <translation>Paketit, jotka tullaan asentamaan:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <source>Done</source>
        <translation>Valmis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Processing finished successfully.</source>
        <translation>Käsittely päättyi onnistuneesti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3471"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <source>Install complete.</source>
        <translation>Asennus valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3480"/>
        <location filename="../src/mainwindow.cpp" line="3497"/>
        <location filename="../src/mainwindow.cpp" line="4437"/>
        <location filename="../src/mainwindow.cpp" line="4550"/>
        <location filename="../src/mainwindow.cpp" line="4583"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Asennuksen aikana havaittiin ongelma, tutki konsolitulostetta.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3507"/>
        <source>About %1</source>
        <translation>%1 lisätietoja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3508"/>
        <source>Version: </source>
        <translation>Versio: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3510"/>
        <source>Package Installer for MX Linux</source>
        <translation>Pakettien asennus MX Linux:lle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3512"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3513"/>
        <source>%1 License</source>
        <translation>%1 lisenssi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3519"/>
        <source>%1 Help</source>
        <translation>%1 ohje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3615"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Poistetaan flatpak asennuksia...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3621"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Uninstall complete.</source>
        <translation>Poisto valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3622"/>
        <location filename="../src/mainwindow.cpp" line="4671"/>
        <source>Refreshing flatpaks...</source>
        <translation>Virkistetään flatpak...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Poistamisen aikana kohdattiin ongelma, tarkista tuloste.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Success</source>
        <translation>Onnistui</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Ohjelman poistamisen aikana kohdattiin ongelma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3801"/>
        <location filename="../src/mainwindow.cpp" line="3852"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Ei voitu ladata pakettiluetteloa. Tarkista APT-lähteet.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3900"/>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ei ole asennettuna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3901"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak ei ole tällä hetkellä asennettuna.
Voinko asentaa sen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak ei ole asennettuna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3969"/>
        <source>Needs re-login</source>
        <translation>Kirjautuminen uudelleen tarvitaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3970"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Sinun tulee kirjautua ulos ja takaisin sisään, jotta asennetut kohteet ilmestyvät valikkoon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4320"/>
        <source>Mark keep</source>
        <translation>Merkitse pidä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <source>Select/deselect all upgradable</source>
        <translation>Valitse kaikki päivitettävät/poista valinnat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4162"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Valitse kaikki autom. poistettavat/poista valinnat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <source>Upgrade</source>
        <translation>Päivitä</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <location filename="../src/mainwindow.cpp" line="4629"/>
        <source>Quit?</source>
        <translation>Lopeta?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Prosessi on edelleen käynnissä, lopettaminen saattaa jättää järjestelmän epävakaaseen tilaan. &lt;p&gt;&lt;b&gt; Haluatko poistua MX Sovellukset ohjelmasta?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Reinstall</source>
        <translation>Asenna uudelleen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4542"/>
        <source>Update complete.</source>
        <translation>Päivitys valmis.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4680"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Ongelma havaittiin viimeisen toiminnon aikana, tarkista mitä konsolissa sanotaan.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4708"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Mahdollisesti vaarallista.
Varmista, että tarkistat huolellisesti poistettavien pakettien luettelo.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Hallinnoi flatpak-ohjelmalähteitä</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Kaikille käyttäjille</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Vain minulle</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>kirjoita flatpak-ohjelmalähteen URL-osoite</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>kirjoita flatpakref-sijainti asentaaksesi sovelluksen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Lisää tai poista flatpak arkistot (ohjelmavarastot), tai asenna sovelluksia käyttäen flatpakref URL-osoitetta tai polkua</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Poista ohjelmalähde</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Lisää ohjelmalähde</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Asenna sovellus</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Ei poistettavissa</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub on ensisijainen flatpak-ohjelmalähde ja sitä ei voi poistaa</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Virhe lisättäessä ohjelmalähdettä</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Ohjelmalähdettä ei voitu lisätä - käsky palautti virheen. Tarkista ohjelmalähteen osoite ja yritä uudelleen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Onnistui</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Ohjelmalähde lisätty onnistuneesti</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Arkiston versio</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Asennettu</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategoria</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paketti</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Ei voi ladata %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Lisenssi</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Muutosloki</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Muutoslokin lataaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Sulje</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Toinen ohjelma on lukinnut Dpkg/apt-tietokannan: %1
Sulje ohjelma tai odota, kunnes se on valmiina  ja yritä uudelleen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Sovellukset on työkalu pakettien hallintaan MX Linux:ssa
    - asentaa suosittuja ohjelmia eri lähteistä
    - asentaa ohjelmia MX testilähteestä
    - asentaa ohjelmia Debian Backports lähteestä
    - asentaa flatpak-ohjelmia</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Ohita verkkotarkistus, jos se ilmoittaa virheellisen Internet-yhteyden puutteen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Olet kirjautunut sisään pääkäyttäjänä. Kirjaudu sisään normaalina käyttäjänä käyttääksesi tätä ohjelmaa.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Tämä ohjelma on suoritettava järjestelmänvalvojan oikeuksilla.</translation>
    </message>
</context>
</TS>