<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="da">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="155"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="157"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="159"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="161"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="163"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="295"/>
        <source>MX Package Installer</source>
        <translation>MX Pakkeinstallationsprogram</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Populære programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>søg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Opgrader alle</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Installeret:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Samlet pakker:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Kan opgraderes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Skjul biblioteks- og udviklerpakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Genopfrisk liste</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrer pakker efter deres status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4120"/>
        <source>All packages</source>
        <translation>Alle pakker</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4146"/>
        <source>Installed</source>
        <translation>Installeret</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4147"/>
        <source>Upgradable</source>
        <translation>Kan opgraderes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4113"/>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <source>Not installed</source>
        <translation>Ikke installeret</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3486"/>
        <location filename="../src/mainwindow.cpp" line="4084"/>
        <location filename="../src/mainwindow.cpp" line="4149"/>
        <location filename="../src/mainwindow.cpp" line="4228"/>
        <location filename="../src/mainwindow.cpp" line="4319"/>
        <source>Autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX test-softwarekilde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian-backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="278"/>
        <location filename="../src/mainwindow.cpp" line="279"/>
        <source>For all users</source>
        <translation>For alle brugere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>For nuværende bruger</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Fjern (repo):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4095"/>
        <source>All apps</source>
        <translation>Alle programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4101"/>
        <source>All runtimes</source>
        <translation>Alle runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4107"/>
        <source>All available</source>
        <translation>Alle tilgængelige</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4092"/>
        <source>Installed apps</source>
        <translation>Installerede programmer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4089"/>
        <source>Installed runtimes</source>
        <translation>Installerede runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4111"/>
        <source>All installed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>Samlet størrelse</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Installerede programmer:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Avanceret</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Samlet installeret størrelse:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3655"/>
        <location filename="../src/mainwindow.cpp" line="3965"/>
        <source>Console Output</source>
        <translation>Konsoloutput</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Svar her, eller tryk blot på Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="1997"/>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <location filename="../src/mainwindow.cpp" line="4345"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation>Afslut programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Luk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+L</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Vis hjælp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Afinstaller</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="490"/>
        <source>Uninstalling packages...</source>
        <translation>Afinstallerer pakker...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="495"/>
        <source>Running pre-uninstall operations...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="515"/>
        <source>Running post-uninstall operations...</source>
        <translation>Kører handlinger for efter-installation ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="532"/>
        <source>Refreshing sources...</source>
        <translation>Genopfrisker kilder...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="545"/>
        <location filename="../src/mainwindow.cpp" line="2045"/>
        <location filename="../src/mainwindow.cpp" line="2187"/>
        <location filename="../src/mainwindow.cpp" line="2356"/>
        <location filename="../src/mainwindow.cpp" line="2433"/>
        <location filename="../src/mainwindow.cpp" line="2792"/>
        <location filename="../src/mainwindow.cpp" line="3036"/>
        <location filename="../src/mainwindow.cpp" line="3479"/>
        <location filename="../src/mainwindow.cpp" line="3496"/>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="3800"/>
        <location filename="../src/mainwindow.cpp" line="3851"/>
        <location filename="../src/mainwindow.cpp" line="4436"/>
        <location filename="../src/mainwindow.cpp" line="4549"/>
        <location filename="../src/mainwindow.cpp" line="4582"/>
        <location filename="../src/mainwindow.cpp" line="4679"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="546"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Der var et problem med at opdatere kilder. Nogle kilder har måske ikke leveret opdateringer. For mere info, tjek: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="664"/>
        <location filename="../src/mainwindow.cpp" line="691"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="697"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1248"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <source>Please wait...</source>
        <translation>Vent venligst...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1806"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Du er ved at bruge MX test-softwarekilden, med pakker som kun leveres til testformål. Der er mulighed for at de kan gøre dit system ubrugeligt, så det foreslås at du sikkerhedskopierer dit system og kun installerer én pakke af gangen. Giv venligst feedback i forummet så pakken kan evalueres inden den flyttes til Main.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1815"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Du er ved at bruge Debian backports, som indeholder pakker som er taget fra den næste Debian-udgivelse (kaldet &apos;testing&apos;), justeret og genkompileret til brug i Debian stable. De kan ikke testes så omfattende som i de stabile udgivelser af Debian og MX Linux, og leveres på et som-de-er grundlag, med risiko for inkompatibilitet med andre komponenter i Debian stable. Brug med forsigtighed!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1823"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux inkluderer kun denne softwarekilde af flatpaks for at gøre det let for brugerne, og er ikke ansvarlig for funktionaliteten af de enkelte flatpaks. Konsulter flatpaks i wikien for mere.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1831"/>
        <location filename="../src/mainwindow.cpp" line="4707"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1835"/>
        <source>Do not show this message again</source>
        <translation>Vis ikke meddelelsen igen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1994"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2010"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2046"/>
        <location filename="../src/mainwindow.cpp" line="2188"/>
        <location filename="../src/mainwindow.cpp" line="2434"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internettet er ikke tilgængeligt, vil ikke være i stand til at downloade listen over pakkerne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2049"/>
        <source>Installing packages...</source>
        <translation>Installerer pakker...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2112"/>
        <source>Post-processing...</source>
        <translation>Efterbehandling...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2144"/>
        <source>Pre-processing for </source>
        <translation>Præbehandling til </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2159"/>
        <source>Installing </source>
        <translation>Installerer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2166"/>
        <source>Post-processing for </source>
        <translation>Efterbehandling til </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2357"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2442"/>
        <source>Downloading package info...</source>
        <translation>Downloader pakkeinfo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3037"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3172"/>
        <location filename="../src/mainwindow.cpp" line="3291"/>
        <location filename="../src/mainwindow.cpp" line="3321"/>
        <source>Package info</source>
        <translation>Pakkeinfo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3200"/>
        <location filename="../src/mainwindow.cpp" line="4618"/>
        <source>More &amp;info...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3234"/>
        <source>Packages to be installed: </source>
        <translation>Pakker som skal installeres: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <source>Done</source>
        <translation>Færdig</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3462"/>
        <location filename="../src/mainwindow.cpp" line="3475"/>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="3607"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4433"/>
        <location filename="../src/mainwindow.cpp" line="4545"/>
        <location filename="../src/mainwindow.cpp" line="4576"/>
        <location filename="../src/mainwindow.cpp" line="4675"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Processing finished successfully.</source>
        <translation>Behandlingen blev færdig.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3471"/>
        <location filename="../src/mainwindow.cpp" line="4571"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3480"/>
        <location filename="../src/mainwindow.cpp" line="3497"/>
        <location filename="../src/mainwindow.cpp" line="4437"/>
        <location filename="../src/mainwindow.cpp" line="4550"/>
        <location filename="../src/mainwindow.cpp" line="4583"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Problem registreret under installation, inspicer venligst outputtet fra konsolen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3507"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3508"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3510"/>
        <source>Package Installer for MX Linux</source>
        <translation>Pakkeinstallationsprogram til MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3512"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Ophavsret (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3513"/>
        <source>%1 License</source>
        <translation>%1-licens</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3519"/>
        <source>%1 Help</source>
        <translation>%1-hjælp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3615"/>
        <location filename="../src/mainwindow.cpp" line="4668"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3621"/>
        <location filename="../src/mainwindow.cpp" line="4670"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3622"/>
        <location filename="../src/mainwindow.cpp" line="4671"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3633"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Vi stødte på et problem under afinstallation, tjek venligst outputtet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3644"/>
        <location filename="../src/mainwindow.cpp" line="4714"/>
        <source>Success</source>
        <translation>Det lykkedes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="4717"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Vi stødte på et problem ved afinstallation af programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3801"/>
        <location filename="../src/mainwindow.cpp" line="3852"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3900"/>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ikke installeret</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3901"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak er ikke installeret.
Er det OK at fortsætte og installere den?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3946"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak blev ikke installeret</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3969"/>
        <source>Needs re-login</source>
        <translation>Behøver genindlodning</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3970"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Der kan være du skal logge ud og ind og se de installerede punkter i menuen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4133"/>
        <location filename="../src/mainwindow.cpp" line="4144"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4320"/>
        <source>Mark keep</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4162"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4258"/>
        <location filename="../src/mainwindow.cpp" line="4318"/>
        <source>Upgrade</source>
        <translation>Opgrader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4465"/>
        <location filename="../src/mainwindow.cpp" line="4629"/>
        <source>Quit?</source>
        <translation>Afslut?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4630"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Processen kører stadig, afslutning kan efterlade systemet i en ustabil tilstand.&lt;p&gt;&lt;b&gt;Er du sikker på, at du vil afslutte MX Pakkeinstallationsprogrammet?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4298"/>
        <source>Reinstall</source>
        <translation>Geninstaller</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4542"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4680"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4708"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Håndter Flatpak-fjern</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>For alle brugere</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>For nuværende bruger</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>Indtast URL for Flatpak-fjern</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>indtast Flatpakref-placering for at installere program</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Tilføj eller fjern flatpak-fjerne (softwarekilder) eller installer programmer med flatpakref-URL eller -sti</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Fjern fjern</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Tilføj fjern</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Installer program</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Luk</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="81"/>
        <source>Not removable</source>
        <translation>Ikke flytbar</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub er den primære Flatpak-fjern og tilføjes ikke</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="101"/>
        <source>Error adding remote</source>
        <translation>Fejl ved tilføjelse af fjern</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="102"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Kunne ikke tilføje fjern - kommandoen returnerede en fejl. Dobbelttjek venligt fjernadressen og prøv igen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Success</source>
        <translation>Det lykkedes</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="107"/>
        <source>Remote added successfully</source>
        <translation>Fjern blev tilføjet</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Installeret</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Ændringslog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Luk</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Fejl</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>