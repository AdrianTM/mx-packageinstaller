<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sv">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation>Administratörbehörighet krävs</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Denna operation kräver administratörprivilegier. Var vänlig starta om programmet  och skriv in ditt lösenord när det krävs.</translation>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="152"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="154"/>
        <source>Full Name</source>
        <translation>Fullständigt namn</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="156"/>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="158"/>
        <source>Branch</source>
        <translation>Gren</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="160"/>
        <source>Size</source>
        <translation>Storlek</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="305"/>
        <source>MX Package Installer</source>
        <translation>MX Paket-installerare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Populära Program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Hantera populära paket&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>sök</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Installerade paket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Aktiverade Förråd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ta bort alla paket som är markerade som &amp;quot;autoremovable&amp;quot;. Om du vill hantera dem, välj Autoremovable i den dragbara markeringsrutan.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation>Autoremove paket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Uppgradera alla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Installerade:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Totalt antal paket:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Installera även &quot;Rekommenderade&quot; Paket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Uppgraderingsbara:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Göm library och utvecklare-paket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Förnya listan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtrera paket enligt deras status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <source>All packages</source>
        <translation>Alla paket</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Installed</source>
        <translation>Installerad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4175"/>
        <source>Upgradable</source>
        <translation>Uppgraderingsbar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <location filename="../src/mainwindow.cpp" line="4176"/>
        <source>Not installed</source>
        <translation>Inte installerad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3509"/>
        <location filename="../src/mainwindow.cpp" line="4112"/>
        <location filename="../src/mainwindow.cpp" line="4177"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4347"/>
        <source>Autoremovable</source>
        <translation>Autoremovable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Paket som kan uppgraderas. Nyare version finns i valt förråd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>MX Test Repo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>For all users</source>
        <translation>För alla användare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>För nuvarande användare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Fjärr (förråd):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4123"/>
        <source>All apps</source>
        <translation>Alla program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4129"/>
        <source>All runtimes</source>
        <translation>Alla runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4135"/>
        <source>All available</source>
        <translation>Alla tillgängliga</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4120"/>
        <source>Installed apps</source>
        <translation>Installerade program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4117"/>
        <source>Installed runtimes</source>
        <translation>Installerade runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4139"/>
        <source>All installed</source>
        <translation>Alla installerade</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>Alla poster</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>Installerade program:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Avancerat</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Total storlek installerad:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Ta bort oanvända runtimes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation>Välj alla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation>Bara paket från förråd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3683"/>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <source>Console Output</source>
        <translation>Terminal Output</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Svara här, eller tryck bara på Enter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="2008"/>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <location filename="../src/mainwindow.cpp" line="4172"/>
        <location filename="../src/mainwindow.cpp" line="4286"/>
        <location filename="../src/mainwindow.cpp" line="4326"/>
        <location filename="../src/mainwindow.cpp" line="4346"/>
        <location filename="../src/mainwindow.cpp" line="4373"/>
        <source>Install</source>
        <translation>Installera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation>Avsluta programmet</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Om detta program</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>Om...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Visa hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Avinstallera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="500"/>
        <source>Uninstalling packages...</source>
        <translation>Avinstallerar paket...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Kör operationer före avinstallering...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="525"/>
        <source>Running post-uninstall operations...</source>
        <translation>Kör efterinstallations-process...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="542"/>
        <source>Refreshing sources...</source>
        <translation>Uppdaterar källor...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="555"/>
        <location filename="../src/mainwindow.cpp" line="2060"/>
        <location filename="../src/mainwindow.cpp" line="2198"/>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <location filename="../src/mainwindow.cpp" line="2802"/>
        <location filename="../src/mainwindow.cpp" line="3046"/>
        <location filename="../src/mainwindow.cpp" line="3502"/>
        <location filename="../src/mainwindow.cpp" line="3519"/>
        <location filename="../src/mainwindow.cpp" line="3661"/>
        <location filename="../src/mainwindow.cpp" line="3675"/>
        <location filename="../src/mainwindow.cpp" line="3828"/>
        <location filename="../src/mainwindow.cpp" line="3879"/>
        <location filename="../src/mainwindow.cpp" line="4469"/>
        <location filename="../src/mainwindow.cpp" line="4568"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <location filename="../src/mainwindow.cpp" line="4700"/>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="556"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Det blev ett problem vid uppdatering av källorna. Några källor kanske inte har haft några uppdateringar. För mer info kolla:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation>Kunde inte bestämma Debian version. Var vänlig välj din version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="707"/>
        <source>Debian Version</source>
        <translation>Debian Version</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1264"/>
        <source>Please wait...</source>
        <translation>Var vänlig vänta...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1811"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Du kommer att använda MX Test-förråd, vars paket enbart är avsedda för testning. Det är möjligt att de får ditt system att sluta fungera, så du uppmanas att göra backup av systemet och enbart installera eller uppdatera ett paket i taget. Var vänlig ge feedback på forumet så paketet kan utvärderas innan det flyttas till Main.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1820"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Du är på väg att använda Debian Backports, som innehåller paket från nästa Debianutgåva (kallad &apos;testing&apos;), justerade och omkompilerade för användning i Debian stable. De kan inte testas lika noga som i de stabila utgåvorna av Debian och MX Linux, och kommer som de är, med risk för inkompatibilitet med andra komponenter i Debian stable. Använd försiktigt!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1828"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux inkluderar detta förråd av flatpaks enbart för anvädarnas bekvämlighet och är inte ansvarigt för funktionen av enskilda flatpaks. För mer information, se flatpaks i Wiki.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <location filename="../src/mainwindow.cpp" line="4728"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1840"/>
        <source>Do not show this message again</source>
        <translation>Visa inte det här meddelandet igen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2005"/>
        <source>Remove</source>
        <translation>Ta bort</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2021"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>Följande paket valdes. Klicka för att se detaljer i ändringslistan.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2061"/>
        <location filename="../src/mainwindow.cpp" line="2199"/>
        <location filename="../src/mainwindow.cpp" line="2444"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet inte tillgängligt, kan inte ladda ner paketlistan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2064"/>
        <source>Installing packages...</source>
        <translation>Installerar paketen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>Post-processing...</source>
        <translation>Efterbehandlar...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2155"/>
        <source>Pre-processing for </source>
        <translation>Förbereder för</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>Installing </source>
        <translation>Installerar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2177"/>
        <source>Post-processing for </source>
        <translation>Efterbehandlar för</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2367"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation>Ett fel uppstod vid nerladdning eller skrivning till filen: %1. Var vänlig kontrollera din internetförbindelse och ledigt utrymme på din disk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2452"/>
        <source>Downloading package info...</source>
        <translation>Laddar ner paketinformation...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2803"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>dpkg-query kommandot gav ett fel. Var vänlig kör &apos;dpkg-query -W&apos; i en terminal och kolla resultatet..</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3047"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation>dpkg-query kommandot gav ett fel, var vänlig kör &apos;dpkg-query -W&apos; i en terminal och kontrollera utdata.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3181"/>
        <location filename="../src/mainwindow.cpp" line="3304"/>
        <location filename="../src/mainwindow.cpp" line="3338"/>
        <source>Package info</source>
        <translation>Paketinformation</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3211"/>
        <location filename="../src/mainwindow.cpp" line="4639"/>
        <source>More &amp;info...</source>
        <translation>Mer &amp;info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3245"/>
        <source>Packages to be installed: </source>
        <translation>Paket som ska installeras:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3481"/>
        <location filename="../src/mainwindow.cpp" line="3498"/>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3657"/>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4564"/>
        <location filename="../src/mainwindow.cpp" line="4597"/>
        <location filename="../src/mainwindow.cpp" line="4696"/>
        <source>Done</source>
        <translation>Klar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3481"/>
        <location filename="../src/mainwindow.cpp" line="3498"/>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3657"/>
        <location filename="../src/mainwindow.cpp" line="3672"/>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4564"/>
        <location filename="../src/mainwindow.cpp" line="4597"/>
        <location filename="../src/mainwindow.cpp" line="4696"/>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Processing finished successfully.</source>
        <translation>Processen framgångsrikt avslutad.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Install complete.</source>
        <translation>Installation komplett.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3503"/>
        <location filename="../src/mainwindow.cpp" line="3520"/>
        <location filename="../src/mainwindow.cpp" line="4470"/>
        <location filename="../src/mainwindow.cpp" line="4569"/>
        <location filename="../src/mainwindow.cpp" line="4604"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>Problem hittade under installationen, var vänlig kolla terminal-output.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3530"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3531"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3533"/>
        <source>Package Installer for MX Linux</source>
        <translation>Paketinstallerare för MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3535"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3536"/>
        <source>%1 License</source>
        <translation>%1 Licens</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3542"/>
        <source>%1 Help</source>
        <translation>%1 Hjälp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3638"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <source>Uninstalling flatpaks...</source>
        <translation>Avinstallerar flatpaks...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="4691"/>
        <source>Uninstall complete.</source>
        <translation>Avinstallation komplett.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3648"/>
        <location filename="../src/mainwindow.cpp" line="4692"/>
        <source>Refreshing flatpaks...</source>
        <translation>Uppdaterar flatpaks...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3661"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Vi mötte ett problem vid avinstallering, var vänlig kolla output</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3672"/>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Success</source>
        <translation>Det lyckades</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3675"/>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>Vi stötte på ett problem när programmet avinstallerades</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3829"/>
        <location filename="../src/mainwindow.cpp" line="3880"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Kunde inte ladda ned paketlistan. Var vänlig kontrollera dina APT-källor.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3928"/>
        <location filename="../src/mainwindow.cpp" line="3974"/>
        <source>Flatpak not installed</source>
        <translation>Flatpak ej installerad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3929"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Flatpak är ej installerad.
OK att fortsätta och installera det?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3974"/>
        <source>Flatpak was not installed</source>
        <translation>Flatpak blev ej installerad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3997"/>
        <source>Needs re-login</source>
        <translation>Behöver logga in igen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3998"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Du kan behöva logga ut/logga in för att se installerade poster i menyn</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <location filename="../src/mainwindow.cpp" line="4172"/>
        <location filename="../src/mainwindow.cpp" line="4284"/>
        <location filename="../src/mainwindow.cpp" line="4348"/>
        <source>Mark keep</source>
        <translation>Markera behåll</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4189"/>
        <source>Select/deselect all upgradable</source>
        <translation>Välj/avmarkera alla uppgraderingsbara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4190"/>
        <source>Select/deselect all autoremovable</source>
        <translation>Välj/avmarkera alla autoremovable</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4286"/>
        <location filename="../src/mainwindow.cpp" line="4346"/>
        <source>Upgrade</source>
        <translation>Uppgradera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <location filename="../src/mainwindow.cpp" line="4650"/>
        <source>Quit?</source>
        <translation>Avsluta?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4499"/>
        <location filename="../src/mainwindow.cpp" line="4651"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Process körs fortfarande, att avsluta kan lämna systemet i ett instabilt tillstånd.&lt;p&gt;&lt;b&gt;Är du säker att du vill avsluta MX Paket-installerare?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4326"/>
        <source>Reinstall</source>
        <translation>Ominstallera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4561"/>
        <source>Update complete.</source>
        <translation>Uppdatering komplett.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4701"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Problem upptäcktes vid sista operationen, var vänlig kontrollera  konsol-output.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4729"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Potentiellt dfarlig operation.
Var vänlig kontrollera listan över paket som ska tas bort noga.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Hantera Flatpak Fjärr</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>För alla användare</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>För nuvarande användare</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>Skriv in Flatpak fjärr URL</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>skriv in Flatpakref belägenhet för att installera program</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Lägg till eller ta bort flatpak fjärr (förråd), eller installera program med flatpakref URL eller sökväg</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Ta bort fjärr</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Lägg till fjärr</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Installera program</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Stäng</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Går ej att ta bort</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub är den huvudsakliga Flatpak fjärr och kommer inte att tas bort</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>Fel vid tillägg av fjärr</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Kunde inte lägga till fjärr - kommandot gav ett fel. Var vänlig dubbelkolla fjärr-adressen och försök igen</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Det lyckades</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>Tillägg av fjärr lyckades</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation>Förrådsversion</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Installerad</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Kategori</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Paket</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Beskrivning</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Kunde inte ladda %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licens</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Ändringslogg</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Kunde inte ladda ändringslogg..</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Stäng</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Varning</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Dpkg/apt databasen är låst av ett annat program: %1
Stäng programet, eller vänta tills det kört klart och försök igen.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Paket-Installerare är ett verktyg för att hantera paket för MX Linux
    - installerar populära program från olika källor
    - installerar program froån MX Test repo
    - installerar program från Debian Backports repo
    - installerar flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Skippa online-kontroll om det felaktigt rapporteras brist på tillgång till internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du verkar vara inloggad som root, var vänlig logga ut och logga in som vanlig användare för att använda detta program.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Du måste köra detta program med administratörsrättigheter.</translation>
    </message>
</context>
</TS>