<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="206"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="207"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>FlatpakModel</name>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="152"/>
        <source>Package</source>
        <translation>Pacchetto</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="154"/>
        <source>Full Name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="156"/>
        <source>Version</source>
        <translation>Versione</translation>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="158"/>
        <source>Branch</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/flatpakmodel.cpp" line="160"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <location filename="../src/mainwindow.cpp" line="305"/>
        <source>MX Package Installer</source>
        <translation>MX Installa Programmi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <source>Popular Applications</source>
        <translation>Applicazioni Popolari</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="76"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Manage popular packages&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt;&quot;&gt;Gestisci pacchetti popolari&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="95"/>
        <location filename="../src/mainwindow.ui" line="177"/>
        <location filename="../src/mainwindow.ui" line="680"/>
        <location filename="../src/mainwindow.ui" line="1071"/>
        <location filename="../src/mainwindow.ui" line="1192"/>
        <source>search</source>
        <translation>cerca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="136"/>
        <location filename="../src/mainwindow.ui" line="202"/>
        <location filename="../src/mainwindow.ui" line="705"/>
        <location filename="../src/mainwindow.ui" line="1151"/>
        <location filename="../src/mainwindow.ui" line="1387"/>
        <source>= Installed packages</source>
        <translation>= Pacchetti installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="159"/>
        <source>Enabled Repos</source>
        <translation>Repo abilitati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Remove all the packages that are marked as &amp;quot;autoremovable&amp;quot;. If you want to manage them, select Autoremovable from drop-down selection box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Autoremove packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="350"/>
        <location filename="../src/mainwindow.ui" line="1268"/>
        <source>Upgrade All</source>
        <translation>Aggiorna tutto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="293"/>
        <location filename="../src/mainwindow.ui" line="524"/>
        <location filename="../src/mainwindow.ui" line="908"/>
        <source>Installed:</source>
        <translation>Installati:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="377"/>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Total packages:</source>
        <translation>Pacchetti Totali:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="363"/>
        <location filename="../src/mainwindow.ui" line="656"/>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Also Install &quot;Recommended&quot; Packages</source>
        <translation>Installa anche i Pacchetti &quot;Raccomandati&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="323"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <location filename="../src/mainwindow.ui" line="901"/>
        <source>Upgradable:</source>
        <translation>Aggiornabili:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="242"/>
        <location filename="../src/mainwindow.ui" line="561"/>
        <location filename="../src/mainwindow.ui" line="936"/>
        <source>Hide library and developer packages</source>
        <translation>Nascondi i pacchetti delle librerie e di sviluppo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="264"/>
        <location filename="../src/mainwindow.ui" line="617"/>
        <location filename="../src/mainwindow.ui" line="995"/>
        <location filename="../src/mainwindow.ui" line="1480"/>
        <source>Refresh list</source>
        <translation>Ricarica elenco</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="458"/>
        <location filename="../src/mainwindow.ui" line="767"/>
        <location filename="../src/mainwindow.ui" line="1101"/>
        <location filename="../src/mainwindow.ui" line="1435"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filter packages according to their status.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Filtra i pacchetti secondo il loro stato.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="461"/>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="774"/>
        <location filename="../src/mainwindow.ui" line="1104"/>
        <location filename="../src/mainwindow.ui" line="1108"/>
        <location filename="../src/mainwindow.cpp" line="4148"/>
        <source>All packages</source>
        <translation>Tutti i pacchetti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="470"/>
        <location filename="../src/mainwindow.ui" line="779"/>
        <location filename="../src/mainwindow.ui" line="1113"/>
        <location filename="../src/mainwindow.cpp" line="4174"/>
        <source>Installed</source>
        <translation>Installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="475"/>
        <location filename="../src/mainwindow.ui" line="784"/>
        <location filename="../src/mainwindow.ui" line="1118"/>
        <location filename="../src/mainwindow.cpp" line="4175"/>
        <source>Upgradable</source>
        <translation>Aggiornabili</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="1123"/>
        <location filename="../src/mainwindow.ui" line="1472"/>
        <location filename="../src/mainwindow.cpp" line="4141"/>
        <location filename="../src/mainwindow.cpp" line="4176"/>
        <source>Not installed</source>
        <translation>Non installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="485"/>
        <location filename="../src/mainwindow.ui" line="794"/>
        <location filename="../src/mainwindow.ui" line="1128"/>
        <location filename="../src/mainwindow.cpp" line="3509"/>
        <location filename="../src/mainwindow.cpp" line="4112"/>
        <location filename="../src/mainwindow.cpp" line="4177"/>
        <location filename="../src/mainwindow.cpp" line="4256"/>
        <location filename="../src/mainwindow.cpp" line="4347"/>
        <source>Autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>= Upgradable package. Newer version available in selected repository.</source>
        <translation>= Pacchetto aggiornabile. Una versione più nuova è disponibile nel repository selezionato.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="500"/>
        <source>MX Test Repo</source>
        <translation>Repo MX Test</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="816"/>
        <source>Debian Backports</source>
        <translation>Debian Backports</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <source>Flatpaks</source>
        <translation>Pacchetti Flatpaks</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1403"/>
        <location filename="../src/mainwindow.ui" line="1407"/>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <location filename="../src/mainwindow.cpp" line="289"/>
        <source>For all users</source>
        <translation>Per tutti gli utenti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1412"/>
        <source>For current user</source>
        <translation>Per l&apos;utente corrente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1497"/>
        <source>Remote (repo):</source>
        <translation>Remote (repo):</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1438"/>
        <location filename="../src/mainwindow.ui" line="1442"/>
        <location filename="../src/mainwindow.cpp" line="4123"/>
        <source>All apps</source>
        <translation>Tutte le app.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1447"/>
        <location filename="../src/mainwindow.cpp" line="4129"/>
        <source>All runtimes</source>
        <translation>Tutti i runtime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1452"/>
        <location filename="../src/mainwindow.cpp" line="4135"/>
        <source>All available</source>
        <translation>Tutte le app disponibili</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1457"/>
        <location filename="../src/mainwindow.cpp" line="4120"/>
        <source>Installed apps</source>
        <translation>App. installate</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1462"/>
        <location filename="../src/mainwindow.cpp" line="4117"/>
        <source>Installed runtimes</source>
        <translation>Runtime installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1467"/>
        <location filename="../src/mainwindow.cpp" line="4139"/>
        <source>All installed</source>
        <translation>Tutti i pacchetti installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Total items </source>
        <translation>N.° totale voci</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1261"/>
        <source>Installed apps:</source>
        <translation>App. installate:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <source>Advanced</source>
        <translation>Avanzate</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1342"/>
        <source>Total installed size:</source>
        <translation>Dimensione tot. degli installati:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <source>Remove unused runtimes</source>
        <translation>Rimuovi i runtime inutilizzati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="277"/>
        <location filename="../src/mainwindow.ui" line="630"/>
        <location filename="../src/mainwindow.ui" line="1008"/>
        <source>Select all</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="571"/>
        <location filename="../src/mainwindow.ui" line="946"/>
        <source>Only repo packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1514"/>
        <location filename="../src/mainwindow.cpp" line="3683"/>
        <location filename="../src/mainwindow.cpp" line="3993"/>
        <source>Console Output</source>
        <translation>Output del Terminale</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1520"/>
        <source>Enter</source>
        <translation>Invio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1530"/>
        <source>Respond here, or just press Enter</source>
        <translation>Rispondi qui, o premi Invio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1589"/>
        <location filename="../src/mainwindow.cpp" line="2008"/>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <location filename="../src/mainwindow.cpp" line="4172"/>
        <location filename="../src/mainwindow.cpp" line="4286"/>
        <location filename="../src/mainwindow.cpp" line="4326"/>
        <location filename="../src/mainwindow.cpp" line="4346"/>
        <location filename="../src/mainwindow.cpp" line="4373"/>
        <source>Install</source>
        <translation>Installa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1595"/>
        <source>Alt+I</source>
        <translation>Alt+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1614"/>
        <source>Quit application</source>
        <translation> Chiudi l&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1617"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1623"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1655"/>
        <source>About this application</source>
        <translation>Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1658"/>
        <source>About...</source>
        <translation>Info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1664"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1702"/>
        <source>Display help </source>
        <translation>Visualizza la guida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1705"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1711"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1727"/>
        <source>Uninstall</source>
        <translation>Disinstalla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1733"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="500"/>
        <source>Uninstalling packages...</source>
        <translation>Disinstallazione in corso dei pacchetti..</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="505"/>
        <source>Running pre-uninstall operations...</source>
        <translation>Operazioni pre-disinstallazione in esecuzione...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="525"/>
        <source>Running post-uninstall operations...</source>
        <translation>Sto eseguendo operazioni post-installazione...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="542"/>
        <source>Refreshing sources...</source>
        <translation>Aggiornamento delle sorgenti...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="555"/>
        <location filename="../src/mainwindow.cpp" line="2060"/>
        <location filename="../src/mainwindow.cpp" line="2198"/>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <location filename="../src/mainwindow.cpp" line="2443"/>
        <location filename="../src/mainwindow.cpp" line="2802"/>
        <location filename="../src/mainwindow.cpp" line="3046"/>
        <location filename="../src/mainwindow.cpp" line="3502"/>
        <location filename="../src/mainwindow.cpp" line="3519"/>
        <location filename="../src/mainwindow.cpp" line="3661"/>
        <location filename="../src/mainwindow.cpp" line="3675"/>
        <location filename="../src/mainwindow.cpp" line="3828"/>
        <location filename="../src/mainwindow.cpp" line="3879"/>
        <location filename="../src/mainwindow.cpp" line="4469"/>
        <location filename="../src/mainwindow.cpp" line="4568"/>
        <location filename="../src/mainwindow.cpp" line="4603"/>
        <location filename="../src/mainwindow.cpp" line="4700"/>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="556"/>
        <source>There was a problem updating sources. Some sources may not have provided updates. For more info check: </source>
        <translation>Si è verificato un problema durante l&apos;aggiornamento delle sorgenti. Alcune di queste potrebbero non aver fornito aggiornamenti. Per maggiori informazioni controlla:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="674"/>
        <location filename="../src/mainwindow.cpp" line="701"/>
        <source>Could not determine Debian version. Please select your version:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="707"/>
        <source>Debian Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1264"/>
        <source>Please wait...</source>
        <translation>Attendi...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1811"/>
        <source>You are about to use the MX Test repository, whose packages are provided for testing purposes only. It is possible that they might break your system, so it is suggested that you back up your system and install or update only one package at a time. Please provide feedback in the Forum so the package can be evaluated before moving up to Main.</source>
        <translation>Stai per utilizzare il repository MX Test, i cui pacchetti sono forniti a solo scopo di test. È possibile che possano danneggiare il sistema, quindi è consigliabile eseguire il backup del sistema e installare o aggiornare solo un pacchetto alla volta. Si prega di fornire un feedback nel forum in modo che il pacchetto possa essere valutato prima di inserirlo nel repo Main.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1820"/>
        <source>You are about to use Debian Backports, which contains packages taken from the next Debian release (called &apos;testing&apos;), adjusted and recompiled for usage on Debian stable. They cannot be tested as extensively as in the stable releases of Debian and MX Linux, and are provided on an as-is basis, with risk of incompatibilities with other components in Debian stable. Use with care!</source>
        <translation>Stai per usare Debian Backports, che contiene pacchetti presi dalla release di Debian più nuova (chiamata &apos;testing&apos;), adattati e ricompilati per poter essere usati su Debian stabile. Non possono essere stati testati cosi ampiamente come nelle versioni stabili di Debian e MX Linux, e sono forniti così come li hanno pensati in Debian Test, con il rischio di incompatibilità con altri componenti di Debian Stable. Usa questo repository con cautela!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1828"/>
        <source>MX Linux includes this repository of flatpaks for the users&apos; convenience only, and is not responsible for the functionality of the individual flatpaks themselves. For more, consult flatpaks in the Wiki.</source>
        <translation>MX Linux include il repository di flatpaks solo per comodità dell&apos;utente e non è responsabile della funzionalità dei singoli flatpak. Per ulteriori informazioni consulta, nel Wiki, l&apos;argomento flatpaks.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1836"/>
        <location filename="../src/mainwindow.cpp" line="4728"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1840"/>
        <source>Do not show this message again</source>
        <translation>Non mostrare più questo messaggio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2005"/>
        <source>Remove</source>
        <translation>Rimuovi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2021"/>
        <source>The following packages were selected. Click Show Details for list of changes.</source>
        <translation>I seguenti pacchetti sono stati selezionati. Clicca su Mostra Dettagli per l&apos;elenco delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2061"/>
        <location filename="../src/mainwindow.cpp" line="2199"/>
        <location filename="../src/mainwindow.cpp" line="2444"/>
        <source>Internet is not available, won&apos;t be able to download the list of packages</source>
        <translation>Internet non è disponibile, non si riesce a scaricare l&apos;elenco dei pacchetti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2064"/>
        <source>Installing packages...</source>
        <translation>Installazione pacchetti in corso..</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2123"/>
        <source>Post-processing...</source>
        <translation>Post-processo in corso...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2155"/>
        <source>Pre-processing for </source>
        <translation>Pre-processo per</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>Installing </source>
        <translation>Installazione in corso</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2177"/>
        <source>Post-processing for </source>
        <translation>Post-processo per</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2367"/>
        <source>There was an error downloading or writing the file: %1. Please check your internet connection and free space on your drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2452"/>
        <source>Downloading package info...</source>
        <translation>Scaricamento informazioni pacchetto in corso..</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2803"/>
        <source>dpkg-query command returned an error. Please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3047"/>
        <source>dpkg-query command returned an error, please run &apos;dpkg-query -W&apos; in terminal and check the output.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3181"/>
        <location filename="../src/mainwindow.cpp" line="3304"/>
        <location filename="../src/mainwindow.cpp" line="3338"/>
        <source>Package info</source>
        <translation>Info Pacchetto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3211"/>
        <location filename="../src/mainwindow.cpp" line="4639"/>
        <source>More &amp;info...</source>
        <translation>Altro &amp; info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3245"/>
        <source>Packages to be installed: </source>
        <translation>Pacchetti da installare:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3481"/>
        <location filename="../src/mainwindow.cpp" line="3498"/>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3657"/>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4564"/>
        <location filename="../src/mainwindow.cpp" line="4597"/>
        <location filename="../src/mainwindow.cpp" line="4696"/>
        <source>Done</source>
        <translation>Fatto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3481"/>
        <location filename="../src/mainwindow.cpp" line="3498"/>
        <location filename="../src/mainwindow.cpp" line="3516"/>
        <location filename="../src/mainwindow.cpp" line="3630"/>
        <location filename="../src/mainwindow.cpp" line="3657"/>
        <location filename="../src/mainwindow.cpp" line="3672"/>
        <location filename="../src/mainwindow.cpp" line="4466"/>
        <location filename="../src/mainwindow.cpp" line="4564"/>
        <location filename="../src/mainwindow.cpp" line="4597"/>
        <location filename="../src/mainwindow.cpp" line="4696"/>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Processing finished successfully.</source>
        <translation>L&apos;elaborazione è terminata correttamente.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3493"/>
        <location filename="../src/mainwindow.cpp" line="4592"/>
        <source>Install complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3503"/>
        <location filename="../src/mainwindow.cpp" line="3520"/>
        <location filename="../src/mainwindow.cpp" line="4470"/>
        <location filename="../src/mainwindow.cpp" line="4569"/>
        <location filename="../src/mainwindow.cpp" line="4604"/>
        <source>Problem detected while installing, please inspect the console output.</source>
        <translation>È stato rilevato un problema durante l&apos;installazione, controlla l&apos;output del terminale.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3530"/>
        <source>About %1</source>
        <translation>Circa %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3531"/>
        <source>Version: </source>
        <translation>Versione:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3533"/>
        <source>Package Installer for MX Linux</source>
        <translation>Programma di installazione pacchetti per MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3535"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3536"/>
        <source>%1 License</source>
        <translation>%1 Licenza</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3542"/>
        <source>%1 Help</source>
        <translation>%1 Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3638"/>
        <location filename="../src/mainwindow.cpp" line="4689"/>
        <source>Uninstalling flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3647"/>
        <location filename="../src/mainwindow.cpp" line="4691"/>
        <source>Uninstall complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3648"/>
        <location filename="../src/mainwindow.cpp" line="4692"/>
        <source>Refreshing flatpaks...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3661"/>
        <source>We encountered a problem uninstalling, please check output</source>
        <translation>Si è verificato un problema nella disinstallazione, controlla l&apos;output</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3672"/>
        <location filename="../src/mainwindow.cpp" line="4735"/>
        <source>Success</source>
        <translation>Successo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3675"/>
        <location filename="../src/mainwindow.cpp" line="4738"/>
        <source>We encountered a problem uninstalling the program</source>
        <translation>È stato riscontrato un problema durante la disinstallazione del programma</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3829"/>
        <location filename="../src/mainwindow.cpp" line="3880"/>
        <source>Could not download the list of packages. Please check your APT sources.</source>
        <translation>Impossibile scaricare l&apos;elenco dei pacchetti. Controlla le tue fonti APT.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3928"/>
        <location filename="../src/mainwindow.cpp" line="3974"/>
        <source>Flatpak not installed</source>
        <translation>Il flatpak non è stato installato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3929"/>
        <source>Flatpak is not currently installed.
OK to go ahead and install it?</source>
        <translation>Il flatpak al momento non è installato.
OK per procedere ad installarlo?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3974"/>
        <source>Flatpak was not installed</source>
        <translation>Il flatpak non è stato installato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3997"/>
        <source>Needs re-login</source>
        <translation>E&apos; necessario rieseguire il Login</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="3998"/>
        <source>You might need to logout/login to see installed items in the menu</source>
        <translation>Potrebbe essere necessario uscire dalla sessione e rieseguire il login per vedere le voci installate nel menu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4161"/>
        <location filename="../src/mainwindow.cpp" line="4172"/>
        <location filename="../src/mainwindow.cpp" line="4284"/>
        <location filename="../src/mainwindow.cpp" line="4348"/>
        <source>Mark keep</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4189"/>
        <source>Select/deselect all upgradable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4190"/>
        <source>Select/deselect all autoremovable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4286"/>
        <location filename="../src/mainwindow.cpp" line="4346"/>
        <source>Upgrade</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4498"/>
        <location filename="../src/mainwindow.cpp" line="4650"/>
        <source>Quit?</source>
        <translation>Esci?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4499"/>
        <location filename="../src/mainwindow.cpp" line="4651"/>
        <source>Process still running, quitting might leave the system in an unstable state.&lt;p&gt;&lt;b&gt;Are you sure you want to exit MX Package Installer?&lt;/b&gt;</source>
        <translation>Il processo è ancora in corso, uscire ora potrebbe lasciare il sistema in uno stato instabile.&lt;p&gt;&lt;b&gt;Sei sicuro di voler uscire da MX Installa Programmi?&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4326"/>
        <source>Reinstall</source>
        <translation>Reinstalla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4561"/>
        <source>Update complete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4701"/>
        <source>Problem detected during last operation, please inspect the console output.</source>
        <translation>Problema riscontrato durante l&apos;ultima operazine, controlla l&apos;output della console.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="4729"/>
        <source>Potentially dangerous operation.
Please make sure you check carefully the list of packages to be removed.</source>
        <translation>Operazioni potenzialmente pericolose.
Assicurati di controllare attentamente l&apos;elenco dei pacchetti da rimuovere.</translation>
    </message>
</context>
<context>
    <name>ManageRemotes</name>
    <message>
        <location filename="../src/remotes.cpp" line="16"/>
        <source>Manage Flatpak Remotes</source>
        <translation>Gestisci i remotes (repo) dei flatpak</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="23"/>
        <source>For all users</source>
        <translation>Per tutti gli utenti</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="24"/>
        <source>For current user</source>
        <translation>Per l&apos;utente corrente</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="35"/>
        <source>enter Flatpak remote URL</source>
        <translation>inserisci l&apos;URL del Flatpak remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="38"/>
        <source>enter Flatpakref location to install app</source>
        <translation>inserisci la localizzazione di Flatpakref per installare app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="40"/>
        <source>Add or remove flatpak remotes (repos), or install apps using flatpakref URL or path</source>
        <translation>Aggiungi o rimuovi remotes (repos) di flatpak, oppure installa apps usando l&apos;URL flatpakref o il percorso di localizzazione</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="49"/>
        <source>Remove remote</source>
        <translation>Rimuovi remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="54"/>
        <source>Add remote</source>
        <translation>Aggiungi remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="59"/>
        <source>Install app</source>
        <translation>Installa app</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="64"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="82"/>
        <source>Not removable</source>
        <translation>Non rimovibile</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="83"/>
        <source>Flathub is the main Flatpak remote and won&apos;t be removed</source>
        <translation>Flathub è il principale remote di Flatpak e non verrà rimosso</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="105"/>
        <source>Error adding remote</source>
        <translation>E&apos; incorso un errore nell&apos;aggiungere il remote</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="106"/>
        <source>Could not add remote - command returned an error. Please double-check the remote address and try again</source>
        <translation>Non si riesce ad aggiugere il remote - il comando ha restituito un errore. Ricontrolla l&apos;indirizzo del remote e prova di nuovo</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Success</source>
        <translation>Operazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/remotes.cpp" line="111"/>
        <source>Remote added successfully</source>
        <translation>Il remote è stato aggiunto con successo</translation>
    </message>
</context>
<context>
    <name>PackageModel</name>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="143"/>
        <source>Package</source>
        <translation>Pacchetto</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="145"/>
        <source>Repo Version</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="147"/>
        <source>Installed</source>
        <translation>Installati</translation>
    </message>
    <message>
        <location filename="../src/models/packagemodel.cpp" line="149"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
</context>
<context>
    <name>PopularModel</name>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="329"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="333"/>
        <source>Package</source>
        <translation>Pacchetto</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="335"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../src/models/popularmodel.cpp" line="337"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="94"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="50"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../src/lockfile.cpp" line="51"/>
        <source>Dpkg/apt database is locked by another program: %1
Close the program, or wait until it is done processing and try again.</source>
        <translation>Il database Dpkg/apt è bloccato da un altro programma: %1
Chiudi il programma o attendi il completamento dell&apos;elaborazione e riprova.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="86"/>
        <source>MX Package Installer is a tool used for managing packages on MX Linux
    - installs popular programs from different sources
    - installs programs from the MX Test repo
    - installs programs from Debian Backports repo
    - installs flatpaks</source>
        <translation>MX Installa Programmi è uno strumento usato per gestire i pacchetti su MX Linux
    - installa programmi popolari da fonti differenti
    - installa programmi dal repo MX Test
    - installa programmi dal repo Debian Backports
    - installa flatpaks</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="94"/>
        <source>Skip online check if it falsely reports lack of internet access.</source>
        <translation>Salta il controllo online se segnala erroneamente la mancanza di accesso a Internet.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="104"/>
        <location filename="../src/main.cpp" line="112"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="105"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembra che tu sia loggato come root, fai il log out e poi il log in come utente normale per usare questo programma.</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>You must run this program with admin access.</source>
        <translation>Devi eseguire questo programma come amministratore.</translation>
    </message>
</context>
</TS>